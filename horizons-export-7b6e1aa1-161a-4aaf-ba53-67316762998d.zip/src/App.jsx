
import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { Toaster } from '@/components/ui/toaster';
import Layout from '@/components/Layout';
import DashboardPage from '@/pages/DashboardPage';
import IvrSystemPage from '@/pages/IvrSystemPage'; 
import CallManagementPage from '@/pages/CallManagementPage';
import ReportsPage from '@/pages/ReportsPage';
import SettingsPage from '@/pages/SettingsPage';
import LoginPage from '@/pages/LoginPage';
import UserManagementPage from '@/pages/UserManagementPage';
import SoftphonesPage from '@/pages/SoftphonesPage';
import PhoneNumbersPage from '@/pages/PhoneNumbersPage';
import ContactsPage from '@/pages/ContactsPage';
import DialpadPage from '@/pages/DialpadPage';
import { supabase } from '@/lib/supabaseClient'; 
import { Progress } from "@/components/ui/progress";
import { Briefcase } from 'lucide-react';

const App = () => {
  const [user, setUser] = useState(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAndSetUser = async (sessionUser) => {
      const { data: userData, error } = await supabase
        .from('users')
        .select('role, full_name')
        .eq('id', sessionUser.id)
        .single();

      if (userData) {
        setUser({ ...sessionUser, ...userData });
      } else {
        setUser(sessionUser); // Use auth user data, role/full_name might be missing from public.users
        if (error && error.code !== 'PGRST116') { // PGRST116: "Exact one row was expected, but 0 rows were found"
          console.error("Error fetching user details:", error);
        } else if (!error && !userData) {
          console.warn(`User ${sessionUser.id} found in auth.users but not in public.users. This might be due to a missing entry or delay in the 'handle_new_user' trigger. Role and full name might be unavailable from custom table.`);
        }
      }
    };
    
    const getSession = async () => {
      const { data: { session } } = await supabase.auth.getSession();
      if (session?.user) {
        await fetchAndSetUser(session.user);
      } else {
        setUser(null);
      }
      setLoading(false);
    };

    getSession();

    const { data: authListener } = supabase.auth.onAuthStateChange(
      async (_event, session) => {
        if (session?.user) {
          await fetchAndSetUser(session.user);
        } else {
          setUser(null);
        }
        // Only set loading to false after the first check or if user becomes null
        // Avoid flickering if session is already established
        if (_event === "INITIAL_SESSION" || !session) {
            setLoading(false); 
        }
      }
    );
    
    return () => {
      if (authListener?.subscription) {
        authListener.subscription.unsubscribe();
      }
    };
  }, []);

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-900 to-slate-900 flex flex-col items-center justify-center text-white">
        <div className="w-24 h-24 bg-gradient-to-r from-green-400 to-blue-500 rounded-xl flex items-center justify-center mb-6 shadow-2xl">
            <Briefcase className="w-12 h-12 text-white animate-pulse" />
        </div>
        <p className="text-2xl font-semibold mb-3 tracking-wider">Initializing PhoneSystem Pro...</p>
        <Progress value={undefined} className="w-1/3 h-2.5 bg-slate-700/50 [&>div]:bg-gradient-to-r [&>div]:from-green-400 [&>div]:to-blue-500 shadow-md" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-900 via-purple-800 to-slate-900 text-foreground">
      <Toaster />
      <Router>
        {!user ? (
          <Routes>
            <Route path="/login" element={<LoginPage />} />
            <Route path="*" element={<Navigate to="/login" />} />
          </Routes>
        ) : (
          <Layout user={user}>
            <Routes>
              <Route path="/" element={<DashboardPage user={user} />} />
              <Route path="/ivr" element={<IvrSystemPage user={user} />} />
              <Route path="/config" element={<CallManagementPage user={user} />} />
              <Route path="/reports" element={<ReportsPage user={user} />} />
              <Route path="/settings" element={<SettingsPage user={user} />} />
              <Route path="/dialpad" element={<DialpadPage user={user} />} />
              <Route path="/contacts" element={<ContactsPage user={user} />} />
              
              {user.role === 'admin' && (
                <>
                  <Route path="/users" element={<UserManagementPage user={user} />} />
                  <Route path="/softphones" element={<SoftphonesPage user={user} />} />
                  <Route path="/phone-numbers" element={<PhoneNumbersPage user={user} />} />
                </>
              )}
              <Route path="*" element={<Navigate to="/" />} />
            </Routes>
          </Layout>
        )}
      </Router>
    </div>
  );
};

export default App;
