
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from '@/components/ui/use-toast';
import { Router as RouterIcon, PlusCircle, Edit3, Trash2, Phone, ShieldAlert, UserCircle, ListTree } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Switch } from "@/components/ui/switch";

const PhoneNumbersPage = ({ user: currentUser }) => {
  const [phoneNumbers, setPhoneNumbers] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentData, setCurrentData] = useState({ 
    id: null, 
    phone_number: '', 
    friendly_name: '', 
    provider: 'Twilio', 
    provider_sid: '',
    capabilities: { voice: true, sms: false, mms: false },
    user_id: null, // Renamed from assigned_to_user_id for consistency with DB schema
    ivr_id: null, // Renamed from assigned_to_ivr_id
  });

  useEffect(() => {
    fetchPhoneNumbers();
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    const { data, error } = await supabase.from('users').select('id, email, full_name').order('full_name', {ascending: true});
    if (error) toast({ title: "Error fetching users", description: error.message, variant: "destructive" });
    else setUsers(data || []);
  };

  const fetchPhoneNumbers = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('phone_numbers')
      .select(`
        *,
        users (id, email, full_name)
      `)
      .order('created_at', { ascending: false });
      
    if (error) {
      toast({ title: "Error fetching phone numbers", description: error.message, variant: "destructive" });
    } else {
      setPhoneNumbers(data.map(n => ({...n, assigned_user_name: n.users?.full_name || n.users?.email })));
    }
    setLoading(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCurrentData(prev => ({ ...prev, [name]: value }));
  };

  const handleCapabilityChange = (capability, checked) => {
    setCurrentData(prev => ({
      ...prev,
      capabilities: { ...prev.capabilities, [capability]: checked }
    }));
  };
  
  const handleAssignmentTypeChange = (type) => {
    if (type === 'user') {
        setCurrentData(prev => ({ ...prev, ivr_id: null }));
    } else if (type === 'ivr') {
        setCurrentData(prev => ({ ...prev, user_id: null }));
    } else { // unassigned
        setCurrentData(prev => ({ ...prev, user_id: null, ivr_id: null }));
    }
  };


  const resetDialog = () => {
    setIsEditing(false);
    setCurrentData({ id: null, phone_number: '', friendly_name: '', provider: 'Twilio', provider_sid: '', capabilities: { voice: true, sms: false, mms: false }, user_id: null, ivr_id: null });
    setShowDialog(false);
  };

  const handleAddNew = () => {
    resetDialog();
    setIsEditing(false);
    setShowDialog(true);
  };

  const handleEdit = (item) => {
    setIsEditing(true);
    setCurrentData({ 
      id: item.id, 
      phone_number: item.phone_number, 
      friendly_name: item.friendly_name || '', 
      provider: item.provider || 'Twilio', 
      provider_sid: item.provider_sid || '',
      capabilities: item.capabilities || { voice: true, sms: false, mms: false },
      user_id: item.user_id || null,
      ivr_id: item.ivr_id || null,
    });
    setShowDialog(true);
  };

  const handleSubmit = async () => {
    if (!currentData.phone_number) {
      toast({ title: "Missing fields", description: "Phone number is required.", variant: "destructive" });
      return;
    }

    setLoading(true);
    const upsertData = { ...currentData };
    delete upsertData.id; 
    
    if (upsertData.user_id === 'none' || upsertData.user_id === '') upsertData.user_id = null;
    if (upsertData.ivr_id === '') upsertData.ivr_id = null;


    let response;
    if (isEditing) {
      response = await supabase.from('phone_numbers').update(upsertData).eq('id', currentData.id);
    } else {
      response = await supabase.from('phone_numbers').insert(upsertData);
    }

    const { error } = response;
    if (error) {
      toast({ title: `Error ${isEditing ? 'updating' : 'adding'} phone number`, description: error.message, variant: "destructive" });
    } else {
      toast({ title: `Phone number ${isEditing ? 'updated' : 'added'} successfully` });
      fetchPhoneNumbers();
      resetDialog();
    }
    setLoading(false);
  };
  
  const handleDelete = async (itemId) => {
    setLoading(true);
    const { error } = await supabase.from('phone_numbers').delete().eq('id', itemId);
    if (error) {
      toast({ title: "Error deleting phone number", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Phone number deleted successfully" });
      fetchPhoneNumbers();
    }
    setLoading(false);
  };
  
  const assignmentType = currentData.user_id ? 'user' : (currentData.ivr_id ? 'ivr' : 'unassigned');


  return (
    <div className="space-y-8">
      <motion.h1 className="text-4xl font-bold text-gradient flex items-center" initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <RouterIcon className="mr-3 h-10 w-10" /> Phone Number Management
      </motion.h1>
      <p className="text-lg text-gray-400">Manage your business phone numbers, their capabilities, and assignments.</p>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogTrigger asChild>
          <Button onClick={handleAddNew} className="bg-green-600 hover:bg-green-700">
            <PlusCircle className="mr-2 h-5 w-5" /> Add New Phone Number
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-lg bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-2xl">{isEditing ? 'Edit Phone Number' : 'Add New Phone Number'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
            <div><Label htmlFor="phone_number">Phone Number (E.164 format)</Label><Input id="phone_number" name="phone_number" value={currentData.phone_number} onChange={handleInputChange} className="bg-slate-700 border-slate-600" placeholder="+1xxxxxxxxxx"/></div>
            <div><Label htmlFor="friendly_name">Friendly Name</Label><Input id="friendly_name" name="friendly_name" value={currentData.friendly_name} onChange={handleInputChange} className="bg-slate-700 border-slate-600" placeholder="e.g., Main Sales Line"/></div>
            <div><Label htmlFor="provider">Provider</Label><Input id="provider" name="provider" value={currentData.provider} onChange={handleInputChange} className="bg-slate-700 border-slate-600"/></div>
            <div><Label htmlFor="provider_sid">Provider SID (Optional)</Label><Input id="provider_sid" name="provider_sid" value={currentData.provider_sid} onChange={handleInputChange} className="bg-slate-700 border-slate-600"/></div>
            
            <fieldset className="border border-slate-600 p-3 rounded-md">
              <legend className="text-sm font-medium text-slate-300 px-1">Capabilities</legend>
              <div className="space-y-2 mt-1">
                <div className="flex items-center justify-between"><Label htmlFor="cap_voice">Voice Enabled</Label><Switch id="cap_voice" checked={currentData.capabilities.voice} onCheckedChange={(checked) => handleCapabilityChange('voice', checked)} /></div>
                <div className="flex items-center justify-between"><Label htmlFor="cap_sms">SMS Enabled</Label><Switch id="cap_sms" checked={currentData.capabilities.sms} onCheckedChange={(checked) => handleCapabilityChange('sms', checked)} /></div>
                <div className="flex items-center justify-between"><Label htmlFor="cap_mms">MMS Enabled</Label><Switch id="cap_mms" checked={currentData.capabilities.mms} onCheckedChange={(checked) => handleCapabilityChange('mms', checked)} /></div>
              </div>
            </fieldset>

            <fieldset className="border border-slate-600 p-3 rounded-md">
                <legend className="text-sm font-medium text-slate-300 px-1">Assignment</legend>
                <Select value={assignmentType} onValueChange={handleAssignmentTypeChange}>
                    <SelectTrigger className="w-full bg-slate-700 border-slate-600 mt-1">
                        <SelectValue placeholder="Select assignment type" />
                    </SelectTrigger>
                    <SelectContent className="bg-slate-700 border-slate-600 text-white">
                        <SelectItem value="unassigned">Unassigned</SelectItem>
                        <SelectItem value="user">Assign to User</SelectItem>
                        <SelectItem value="ivr">Assign to IVR</SelectItem>
                    </SelectContent>
                </Select>

                {assignmentType === 'user' && (
                    <div className="mt-2">
                        <Label htmlFor="user_id">Assign to User</Label>
                        <Select value={currentData.user_id || "none"} onValueChange={(value) => setCurrentData(prev => ({...prev, user_id: value === "none" ? null : value, ivr_id: null}))}>
                            <SelectTrigger id="user_id" className="bg-slate-700 border-slate-600">
                                <SelectValue placeholder="Select user" />
                            </SelectTrigger>
                            <SelectContent className="bg-slate-700 border-slate-600 text-white">
                                <SelectItem value="none">None</SelectItem>
                                {users.map(u => <SelectItem key={u.id} value={u.id}>{u.full_name || u.email}</SelectItem>)}
                            </SelectContent>
                        </Select>
                    </div>
                )}

                {assignmentType === 'ivr' && (
                    <div className="mt-2">
                        <Label htmlFor="ivr_id">Assign to IVR</Label>
                        <Input id="ivr_id" name="ivr_id" value={currentData.ivr_id || ""} onChange={(e) => setCurrentData(prev => ({...prev, ivr_id: e.target.value, user_id: null}))} className="bg-slate-700 border-slate-600" placeholder="Enter IVR ID (e.g., general_ivr)"/>
                    </div>
                )}
            </fieldset>

          </div>
          <DialogFooter>
            <Button variant="outline" onClick={resetDialog} className="text-slate-300 border-slate-600 hover:bg-slate-700">Cancel</Button>
            <Button onClick={handleSubmit} disabled={loading} className="bg-green-600 hover:bg-green-700">
              {loading ? 'Saving...' : (isEditing ? 'Save Changes' : 'Add Number')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Card className="donation-card">
        <CardHeader>
          <CardTitle className="text-xl">Managed Phone Numbers</CardTitle>
        </CardHeader>
        <CardContent>
          {loading && <p>Loading numbers...</p>}
          {!loading && phoneNumbers.length === 0 && <p>No phone numbers configured.</p>}
          {!loading && phoneNumbers.length > 0 && (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700/30">
                    <TableHead className="text-gray-400">Number</TableHead>
                    <TableHead className="text-gray-400">Friendly Name</TableHead>
                    <TableHead className="text-gray-400">Assignment</TableHead>
                    <TableHead className="text-gray-400">Capabilities</TableHead>
                    <TableHead className="text-gray-400">Provider</TableHead>
                    <TableHead className="text-gray-400">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {phoneNumbers.map((item) => (
                    <TableRow key={item.id} className="border-slate-700 hover:bg-slate-700/30">
                      <TableCell className="text-white font-semibold">{item.phone_number}</TableCell>
                      <TableCell className="text-slate-300">{item.friendly_name || 'N/A'}</TableCell>
                      <TableCell className="text-slate-300">
                        {item.user_id ? <span className="flex items-center"><UserCircle className="h-4 w-4 mr-1 text-sky-400"/>{item.assigned_user_name || 'User'}</span> : 
                         item.ivr_id ? <span className="flex items-center"><ListTree className="h-4 w-4 mr-1 text-teal-400"/>IVR: {item.ivr_id}</span> : 
                         <span className="text-slate-500">Unassigned</span>}
                      </TableCell>
                      <TableCell className="text-slate-300">
                        {item.capabilities?.voice && <span className="mr-1 p-1 bg-green-600/30 text-green-300 text-xs rounded">Voice</span>}
                        {item.capabilities?.sms && <span className="mr-1 p-1 bg-blue-600/30 text-blue-300 text-xs rounded">SMS</span>}
                        {item.capabilities?.mms && <span className="mr-1 p-1 bg-purple-600/30 text-purple-300 text-xs rounded">MMS</span>}
                      </TableCell>
                      <TableCell className="text-slate-300">{item.provider}</TableCell>
                      <TableCell className="space-x-1">
                        <Button variant="ghost" size="icon" onClick={() => handleEdit(item)} className="text-blue-400 hover:text-blue-300"><Edit3 className="h-4 w-4" /></Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild><Button variant="ghost" size="icon" className="text-red-400 hover:text-red-300"><Trash2 className="h-4 w-4" /></Button></AlertDialogTrigger>
                          <AlertDialogContent className="bg-slate-800 border-slate-700 text-white">
                            <AlertDialogHeader><AlertDialogTitle>Confirm Deletion</AlertDialogTitle><AlertDialogDescription className="text-slate-400">Delete number {item.phone_number}?</AlertDialogDescription></AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel className="text-slate-300 border-slate-600 hover:bg-slate-700">Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDelete(item.id)} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default PhoneNumbersPage;
