
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from '@/components/ui/use-toast';
import { Contact, PlusCircle, Edit3, Trash2, Phone, Mail, Briefcase } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";

const ContactsPage = ({ user: currentUser }) => {
  const [contacts, setContacts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentData, setCurrentData] = useState({ id: null, name: '', phone_number: '', email: '', company: '', notes: '' });

  useEffect(() => {
    fetchContacts();
  }, []);

  const fetchContacts = async () => {
    setLoading(true);
    // Assuming contacts are per user or admins see all
    // For simplicity, if current user is admin, fetch all, else fetch for user_id
    let query = supabase.from('contacts').select('*').order('name', { ascending: true });
    if (currentUser.role !== 'admin') {
      query = query.eq('user_id', currentUser.id);
    }
    
    const { data, error } = await query;

    if (error) {
      toast({ title: "Error fetching contacts", description: error.message, variant: "destructive" });
    } else {
      setContacts(data);
    }
    setLoading(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCurrentData(prev => ({ ...prev, [name]: value }));
  };

  const resetDialog = () => {
    setIsEditing(false);
    setCurrentData({ id: null, name: '', phone_number: '', email: '', company: '', notes: '' });
    setShowDialog(false);
  };

  const handleAddNew = () => {
    resetDialog();
    setIsEditing(false);
    setShowDialog(true);
  };

  const handleEdit = (item) => {
    setIsEditing(true);
    setCurrentData({ 
      id: item.id, 
      name: item.name, 
      phone_number: item.phone_number, 
      email: item.email || '', 
      company: item.company || '', 
      notes: item.notes || '' 
    });
    setShowDialog(true);
  };

  const handleSubmit = async () => {
    if (!currentData.name || !currentData.phone_number) {
      toast({ title: "Missing fields", description: "Name and Phone Number are required.", variant: "destructive" });
      return;
    }

    setLoading(true);
    const upsertData = { 
      ...currentData,
      user_id: currentUser.id // Assign contact to the logged-in user
    };
    delete upsertData.id;

    let response;
    if (isEditing) {
      response = await supabase.from('contacts').update(upsertData).eq('id', currentData.id).eq('user_id', currentUser.id);
    } else {
      response = await supabase.from('contacts').insert(upsertData);
    }

    const { error } = response;
    if (error) {
      toast({ title: `Error ${isEditing ? 'updating' : 'adding'} contact`, description: error.message, variant: "destructive" });
    } else {
      toast({ title: `Contact ${isEditing ? 'updated' : 'added'} successfully` });
      fetchContacts();
      resetDialog();
    }
    setLoading(false);
  };
  
  const handleDelete = async (itemId) => {
    setLoading(true);
    const { error } = await supabase.from('contacts').delete().eq('id', itemId).eq('user_id', currentUser.id); // Ensure user can only delete their own
    if (error) {
      toast({ title: "Error deleting contact", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Contact deleted successfully" });
      fetchContacts();
    }
    setLoading(false);
  };

  return (
    <div className="space-y-8">
      <motion.h1 className="text-4xl font-bold text-gradient flex items-center" initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <Contact className="mr-3 h-10 w-10" /> Contacts
      </motion.h1>
      <p className="text-lg text-gray-400">Manage your personal and shared contacts.</p>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogTrigger asChild>
          <Button onClick={handleAddNew} className="bg-green-600 hover:bg-green-700">
            <PlusCircle className="mr-2 h-5 w-5" /> Add New Contact
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-lg bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-2xl">{isEditing ? 'Edit Contact' : 'Add New Contact'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
            <div><Label htmlFor="name">Full Name</Label><Input id="name" name="name" value={currentData.name} onChange={handleInputChange} className="bg-slate-700 border-slate-600"/></div>
            <div><Label htmlFor="phone_number">Phone Number</Label><Input id="phone_number" name="phone_number" value={currentData.phone_number} onChange={handleInputChange} className="bg-slate-700 border-slate-600" placeholder="+1xxxxxxxxxx"/></div>
            <div><Label htmlFor="email">Email Address</Label><Input id="email" name="email" type="email" value={currentData.email} onChange={handleInputChange} className="bg-slate-700 border-slate-600"/></div>
            <div><Label htmlFor="company">Company</Label><Input id="company" name="company" value={currentData.company} onChange={handleInputChange} className="bg-slate-700 border-slate-600"/></div>
            <div><Label htmlFor="notes">Notes</Label><Textarea id="notes" name="notes" value={currentData.notes} onChange={handleInputChange} className="bg-slate-700 border-slate-600" placeholder="Any relevant notes..."/></div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={resetDialog} className="text-slate-300 border-slate-600 hover:bg-slate-700">Cancel</Button>
            <Button onClick={handleSubmit} disabled={loading} className="bg-green-600 hover:bg-green-700">
              {loading ? 'Saving...' : (isEditing ? 'Save Changes' : 'Add Contact')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Card className="donation-card">
        <CardHeader>
          <CardTitle className="text-xl">Contact List</CardTitle>
        </CardHeader>
        <CardContent>
          {loading && <p>Loading contacts...</p>}
          {!loading && contacts.length === 0 && <p>No contacts found. Add one!</p>}
          {!loading && contacts.length > 0 && (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700/30">
                    <TableHead className="text-gray-400">Name</TableHead>
                    <TableHead className="text-gray-400">Phone Number</TableHead>
                    <TableHead className="text-gray-400">Email</TableHead>
                    <TableHead className="text-gray-400">Company</TableHead>
                    <TableHead className="text-gray-400">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {contacts.map((item) => (
                    <TableRow key={item.id} className="border-slate-700 hover:bg-slate-700/30">
                      <TableCell className="text-white font-semibold">{item.name}</TableCell>
                      <TableCell className="text-slate-300">{item.phone_number}</TableCell>
                      <TableCell className="text-slate-300">{item.email || 'N/A'}</TableCell>
                      <TableCell className="text-slate-300">{item.company || 'N/A'}</TableCell>
                      <TableCell className="space-x-1">
                        <Button variant="ghost" size="icon" onClick={() => handleEdit(item)} className="text-blue-400 hover:text-blue-300"><Edit3 className="h-4 w-4" /></Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild><Button variant="ghost" size="icon" className="text-red-400 hover:text-red-300"><Trash2 className="h-4 w-4" /></Button></AlertDialogTrigger>
                          <AlertDialogContent className="bg-slate-800 border-slate-700 text-white">
                            <AlertDialogHeader><AlertDialogTitle>Confirm Deletion</AlertDialogTitle><AlertDialogDescription className="text-slate-400">Delete contact "{item.name}"?</AlertDialogDescription></AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel className="text-slate-300 border-slate-600 hover:bg-slate-700">Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDelete(item.id)} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default ContactsPage;
