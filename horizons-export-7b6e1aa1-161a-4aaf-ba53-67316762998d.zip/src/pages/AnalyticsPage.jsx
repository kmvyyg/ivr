import React from 'react';
import { motion } from 'framer-motion';
import { BarChart2, TrendingUp, Users, DollarSign, Phone, MessageSquare } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { ResponsiveContainer, BarChart, XAxis, YAxis, Tooltip, Legend, Bar, LineChart, Line } from 'recharts';


const donationData = [
  { name: 'Jan', Phone: 4000, SMS: 2400, amt: 2400 },
  { name: 'Feb', Phone: 3000, SMS: 1398, amt: 2210 },
  { name: 'Mar', Phone: 2000, SMS: 9800, amt: 2290 },
  { name: 'Apr', Phone: 2780, SMS: 3908, amt: 2000 },
  { name: 'May', Phone: 1890, SMS: 4800, amt: 2181 },
  { name: 'Jun', Phone: 2390, SMS: 3800, amt: 2500 },
  { name: 'Jul', Phone: 3490, SMS: 4300, amt: 2100 },
];

const donorGrowthData = [
  { month: 'Jan', donors: 50 },
  { month: 'Feb', donors: 65 },
  { month: 'Mar', donors: 80 },
  { month: 'Apr', donors: 75 },
  { month: 'May', donors: 90 },
  { month: 'Jun', donors: 110 },
  { month: 'Jul', donors: 130 },
];

const AnalyticsPage = () => {
  return (
    <div className="space-y-8">
      <motion.h1 
        className="text-4xl font-bold text-gradient"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        Analytics & Performance
      </motion.h1>
      <p className="text-lg text-gray-400">
        Track key metrics, donation trends, and donor engagement over time.
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[
          { title: 'Total Revenue', value: '$125,670', icon: DollarSign, trend: '+15%', color: 'text-green-400' },
          { title: 'New Donors (Month)', value: '130', icon: Users, trend: '+8%', color: 'text-blue-400' },
          { title: 'Conversion Rate', value: '12.5%', icon: TrendingUp, trend: '+1.2%', color: 'text-purple-400' },
          { title: 'Avg. Donation', value: '$45.50', icon: DollarSign, trend: '-2%', color: 'text-yellow-400' },
        ].map((metric, index) => (
          <motion.div
            key={metric.title}
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            transition={{ delay: index * 0.1 }}
          >
            <Card className="donation-card">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-sm font-medium text-gray-300">{metric.title}</CardTitle>
                <metric.icon className={`h-5 w-5 ${metric.color}`} />
              </CardHeader>
              <CardContent>
                <div className="text-2xl font-bold text-white">{metric.value}</div>
                <p className={`text-xs ${metric.trend.startsWith('+') ? 'text-green-400' : 'text-red-400'}`}>
                  {metric.trend} vs last month
                </p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="donation-card">
            <CardHeader>
              <CardTitle className="text-xl text-white flex items-center">
                <BarChart2 className="h-6 w-6 mr-2 text-indigo-400" />
                Donations by Channel (Monthly)
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={donationData}>
                  <XAxis dataKey="name" stroke="#9ca3af" />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip
                    contentStyle={{ backgroundColor: 'rgba(31, 41, 55, 0.8)', border: 'none', borderRadius: '0.5rem' }}
                    labelStyle={{ color: '#e5e7eb' }}
                    itemStyle={{ color: '#d1d5db' }}
                  />
                  <Legend wrapperStyle={{ color: '#9ca3af' }} />
                  <Bar dataKey="Phone" fill="#34d399" name="Phone Donations" radius={[4, 4, 0, 0]} />
                  <Bar dataKey="SMS" fill="#60a5fa" name="SMS Donations" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="donation-card">
            <CardHeader>
              <CardTitle className="text-xl text-white flex items-center">
                <TrendingUp className="h-6 w-6 mr-2 text-pink-400" />
                Donor Growth Over Time
              </CardTitle>
            </CardHeader>
            <CardContent>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={donorGrowthData}>
                  <XAxis dataKey="month" stroke="#9ca3af" />
                  <YAxis stroke="#9ca3af" />
                  <Tooltip 
                    contentStyle={{ backgroundColor: 'rgba(31, 41, 55, 0.8)', border: 'none', borderRadius: '0.5rem' }}
                    labelStyle={{ color: '#e5e7eb' }}
                    itemStyle={{ color: '#d1d5db' }}
                  />
                  <Legend wrapperStyle={{ color: '#9ca3af' }} />
                  <Line type="monotone" dataKey="donors" stroke="#f472b6" strokeWidth={2} dot={{ r: 4 }} activeDot={{ r: 6 }} />
                </LineChart>
              </ResponsiveContainer>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default AnalyticsPage;