import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from '@/components/ui/use-toast';
import { PhoneCall, PlusCircle, Edit3, Trash2, Link2, Wifi, WifiOff, Save, Zap } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";
import { Switch } from "@/components/ui/switch"; // Added missing import

const SoftphonesPage = ({ user: currentUser }) => {
  const [softphones, setSoftphones] = useState([]);
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showDialog, setShowDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentData, setCurrentData] = useState({ id: null, user_id: '', name: '', type: 'sip_device', sip_username: '', sip_password: '', sip_server: '', is_registered: false });

  useEffect(() => {
    fetchSoftphones();
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    const { data, error } = await supabase.from('users').select('id, email, full_name');
    if (error) toast({ title: "Error fetching users", description: error.message, variant: "destructive" });
    else setUsers(data || []);
  };
  
  const fetchSoftphones = async () => {
    setLoading(true);
    const { data, error } = await supabase
      .from('softphones')
      .select(`
        *,
        users (id, email, full_name)
      `)
      .order('created_at', { ascending: false });
    if (error) {
      toast({ title: "Error fetching softphones", description: error.message, variant: "destructive" });
    } else {
      setSoftphones(data.map(s => ({...s, user_full_name: s.users?.full_name || s.users?.email || 'N/A' })));
    }
    setLoading(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCurrentData(prev => ({ ...prev, [name]: value }));
  };

  const handleSelectChange = (name, value) => {
    setCurrentData(prev => ({ ...prev, [name]: value }));
  };
  
  const handleSwitchChange = (name, checked) => {
    setCurrentData(prev => ({ ...prev, [name]: checked }));
  };

  const resetDialog = () => {
    setIsEditing(false);
    setCurrentData({ id: null, user_id: currentUser?.id || '', name: '', type: 'sip_device', sip_username: '', sip_password: '', sip_server: '', is_registered: false });
    setShowDialog(false);
  };

  const handleAddNew = () => {
    resetDialog();
    setIsEditing(false);
    setShowDialog(true);
  };

  const handleEdit = (item) => {
    setIsEditing(true);
    setCurrentData({ 
      id: item.id, 
      user_id: item.user_id, 
      name: item.name, 
      type: item.type, 
      sip_username: item.sip_username || '', 
      sip_password: '', 
      sip_server: item.sip_server || '',
      is_registered: item.is_registered || false
    });
    setShowDialog(true);
  };

  const handleSubmit = async () => {
    if (!currentData.user_id || !currentData.name || !currentData.type) {
      toast({ title: "Missing fields", description: "User, Name and Type are required.", variant: "destructive" });
      return;
    }

    setLoading(true);
    // Clone currentData and conditionally remove password if not provided during edit
    const upsertData = { ...currentData };
    if (isEditing && !currentData.sip_password) {
      delete upsertData.sip_password;
    }
    delete upsertData.id; // Remove ID for insert, or let Supabase handle it for update

    let response;
    if (isEditing) {
      response = await supabase.from('softphones').update(upsertData).eq('id', currentData.id);
    } else {
      // Ensure user_id is set for new entries
      upsertData.user_id = upsertData.user_id || currentUser.id;
      response = await supabase.from('softphones').insert(upsertData).select().single();
    }

    const { error } = response;
    if (error) {
      toast({ title: `Error ${isEditing ? 'updating' : 'adding'} softphone`, description: error.message, variant: "destructive" });
    } else {
      toast({ title: `Softphone ${isEditing ? 'updated' : 'added'} successfully` });
      fetchSoftphones();
      resetDialog();
    }
    setLoading(false);
  };
  
  const handleDelete = async (itemId) => {
    setLoading(true);
    const { error } = await supabase.from('softphones').delete().eq('id', itemId);
    if (error) {
      toast({ title: "Error deleting softphone", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Softphone deleted successfully" });
      fetchSoftphones();
    }
    setLoading(false);
  };
  
  const toggleRegistration = async (softphone) => {
    const newStatus = !softphone.is_registered;
    const { error } = await supabase
      .from('softphones')
      .update({ is_registered: newStatus, last_registered_at: newStatus ? new Date().toISOString() : null })
      .eq('id', softphone.id);

    if (error) {
      toast({ title: "Failed to update registration", description: error.message, variant: "destructive" });
    } else {
      toast({ title: `Softphone ${newStatus ? 'Registered' : 'Unregistered'}`, description: `${softphone.name} status updated (simulated).` });
      fetchSoftphones();
    }
  };


  if (loading && !users.length) { // Also check if users are loaded if they are needed for the dialog immediately
    return <div className="flex justify-center items-center h-64"><Zap className="h-8 w-8 animate-pulse text-purple-400" /> <span className="ml-2 text-xl">Loading Configurations...</span></div>;
  }


  return (
    <div className="space-y-8">
      <motion.h1 className="text-4xl font-bold text-gradient flex items-center" initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <PhoneCall className="mr-3 h-10 w-10" /> Softphone Management
      </motion.h1>
      <p className="text-lg text-gray-400">Configure and manage softphone connections for users.</p>

      <Dialog open={showDialog} onOpenChange={setShowDialog}>
        <DialogTrigger asChild>
          <Button onClick={handleAddNew} className="bg-green-600 hover:bg-green-700">
            <PlusCircle className="mr-2 h-5 w-5" /> Add Softphone Config
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-lg bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-2xl">{isEditing ? 'Edit Softphone Configuration' : 'Add New Softphone Configuration'}</DialogTitle>
          </DialogHeader>
          <div className="grid gap-4 py-4 max-h-[60vh] overflow-y-auto pr-2">
            <div>
              <Label htmlFor="user_id">User</Label>
              <Select value={currentData.user_id} onValueChange={(value) => handleSelectChange('user_id', value)} >
                <SelectTrigger id="user_id" className="bg-slate-700 border-slate-600">
                  <SelectValue placeholder="Select user" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600 text-white">
                  {users.map(u => <SelectItem key={u.id} value={u.id}>{u.full_name || u.email}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div><Label htmlFor="name">Configuration Name</Label><Input id="name" name="name" value={currentData.name} onChange={handleInputChange} className="bg-slate-700 border-slate-600" placeholder="e.g., Desk Phone T46S"/></div>
            <div>
              <Label htmlFor="type">Type</Label>
              <Select value={currentData.type} onValueChange={(value) => handleSelectChange('type', value)}>
                <SelectTrigger id="type" className="bg-slate-700 border-slate-600">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600 text-white">
                  <SelectItem value="sip_device">SIP Device (e.g., Yealink)</SelectItem>
                  <SelectItem value="webrtc">WebRTC Softphone (Browser)</SelectItem>
                  <SelectItem value="mobile_app">Mobile App</SelectItem>
                </SelectContent>
              </Select>
            </div>
            {(currentData.type === 'sip_device' || currentData.type === 'webrtc') && (
              <>
                <div><Label htmlFor="sip_username">SIP Username</Label><Input id="sip_username" name="sip_username" value={currentData.sip_username} onChange={handleInputChange} className="bg-slate-700 border-slate-600"/></div>
                <div>
                  <Label htmlFor="sip_password">SIP Password</Label>
                  <Input id="sip_password" name="sip_password" type="password" value={currentData.sip_password} onChange={handleInputChange} className="bg-slate-700 border-slate-600" placeholder={isEditing ? 'Leave blank to keep unchanged' : ''}/>
                  <p className="text-xs text-yellow-400 mt-1">Warning: For security, use a secrets manager for passwords in production.</p>
                </div>
                <div><Label htmlFor="sip_server">SIP Server/Domain</Label><Input id="sip_server" name="sip_server" value={currentData.sip_server} onChange={handleInputChange} className="bg-slate-700 border-slate-600" placeholder="e.g., sip.example.com"/></div>
              </>
            )}
             <div className="flex items-center space-x-2 pt-2">
                <Switch id="is_registered" checked={currentData.is_registered} onCheckedChange={(checked) => handleSwitchChange('is_registered', checked)} />
                <Label htmlFor="is_registered" className="cursor-pointer">Is Registered?</Label>
             </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={resetDialog} className="text-slate-300 border-slate-600 hover:bg-slate-700">Cancel</Button>
            <Button onClick={handleSubmit} disabled={loading} className="bg-green-600 hover:bg-green-700">
              <Save className="mr-2 h-4 w-4" />{loading ? 'Saving...' : (isEditing ? 'Save Changes' : 'Add Configuration')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {softphones.length === 0 && !loading && (
        <Card className="donation-card text-center py-12">
          <CardHeader>
            <CardTitle className="text-2xl text-gray-400">No Softphones Configured</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-gray-500 mb-6">Get started by adding your first softphone configuration.</p>
            <Button onClick={handleAddNew} className="bg-green-600 hover:bg-green-700 text-lg px-8 py-6">
              <PlusCircle className="mr-2 h-5 w-5" /> Add Your First Softphone
            </Button>
          </CardContent>
        </Card>
      )}

      {softphones.length > 0 && (
      <Card className="donation-card">
        <CardHeader>
          <CardTitle className="text-xl">Configured Softphones</CardTitle>
        </CardHeader>
        <CardContent>
          {loading ? (<p>Loading configurations...</p>) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700/30">
                    <TableHead className="text-gray-400">User</TableHead>
                    <TableHead className="text-gray-400">Config Name</TableHead>
                    <TableHead className="text-gray-400">Type</TableHead>
                    <TableHead className="text-gray-400">SIP User</TableHead>
                    <TableHead className="text-gray-400">SIP Server</TableHead>
                    <TableHead className="text-gray-400">Status</TableHead>
                    <TableHead className="text-gray-400">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {softphones.map((item) => (
                    <TableRow key={item.id} className="border-slate-700 hover:bg-slate-700/30">
                      <TableCell className="text-white">{item.user_full_name || 'N/A'}</TableCell>
                      <TableCell className="text-slate-300">{item.name}</TableCell>
                      <TableCell className="text-slate-300">{item.type.replace('_', ' ').toUpperCase()}</TableCell>
                      <TableCell className="text-slate-300">{item.sip_username || 'N/A'}</TableCell>
                      <TableCell className="text-slate-300">{item.sip_server || 'N/A'}</TableCell>
                      <TableCell>
                         <Button variant="ghost" size="icon" className={`p-1 ${item.is_registered ? 'text-green-400 hover:text-green-300' : 'text-red-400 hover:text-red-300'}`} onClick={() => toggleRegistration(item)}>
                            {item.is_registered ? <Wifi className="h-5 w-5" /> : <WifiOff className="h-5 w-5" />}
                         </Button>
                         <span className={`ml-1 text-xs ${item.is_registered ? 'text-green-400' : 'text-red-400'}`}>
                             {item.is_registered ? `Online` : 'Offline'}
                         </span>
                      </TableCell>
                      <TableCell className="space-x-1">
                        <Button variant="ghost" size="icon" onClick={() => handleEdit(item)} className="text-blue-400 hover:text-blue-300"><Edit3 className="h-4 w-4" /></Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild><Button variant="ghost" size="icon" className="text-red-400 hover:text-red-300"><Trash2 className="h-4 w-4" /></Button></AlertDialogTrigger>
                          <AlertDialogContent className="bg-slate-800 border-slate-700 text-white">
                            <AlertDialogHeader><AlertDialogTitle>Confirm Deletion</AlertDialogTitle><AlertDialogDescription className="text-slate-400">Delete configuration "{item.name}"?</AlertDialogDescription></AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel className="text-slate-300 border-slate-600 hover:bg-slate-700">Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDelete(item.id)} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
      )}
       <Card className="mt-8 donation-card bg-indigo-900/30 border-indigo-700">
          <CardHeader>
            <CardTitle className="text-lg text-indigo-300 flex items-center"><Zap className="mr-2 h-5 w-5"/>Important Notes on Softphone Integration</CardTitle>
          </CardHeader>
          <CardContent className="text-indigo-200 text-sm space-y-2">
            <p><strong>WebRTC Clients:</strong> For browser-based softphones, you would typically integrate a WebRTC library (like SIP.js or Twilio Client SDK) here. This frontend would handle signaling, media streams, and registration with your SIP server or telephony provider.</p>
            <p><strong>SIP Devices (e.g., Yealink):</strong> Physical SIP phones like Yealink are configured directly on the device itself (via its web interface or provisioning server). They connect to your PBX or SIP Trunk provider. This dashboard can store their configuration details for reference but doesn't directly control their registration beyond what your telephony backend might allow via API.</p>
            <p><strong>Registration Status:</strong> The "Registered" status shown here is simulated. Real-time registration status would require communication with your telephony backend or the softphone client itself.</p>
            <p><strong>Outbound Calling:</strong> To enable outbound calling from this interface through these softphones, you'd need to:
              <ul className="list-disc list-inside pl-4">
                <li>For WebRTC: Trigger the call via the WebRTC library.</li>
                <li>For SIP Devices: Potentially use a "click-to-call" API from your PBX/provider that instructs the registered device to dial out.</li>
              </ul>
            </p>
          </CardContent>
        </Card>
    </div>
  );
};

export default SoftphonesPage;