
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Briefcase, PlayCircle, Voicemail as VoicemailIcon, ListTree } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';
import IvrPromptsManager from '@/components/call-management/IvrPromptsManager';
import VoicemailManager from '@/components/call-management/VoicemailManager';
import ConferenceCallSimulator from '@/components/call-management/ConferenceCallSimulator';

const CallManagementPage = ({ user: currentUser }) => {
  const [prompts, setPrompts] = useState([]);
  const [voicemails, setVoicemails] = useState([]);
  const [loadingPrompts, setLoadingPrompts] = useState(true);
  const [loadingVoicemails, setLoadingVoicemails] = useState(true);
  const [usersMap, setUsersMap] = useState({});

  useEffect(() => {
    fetchIvrPrompts();
    fetchVoicemailsAndUsers();
  }, []);

  const fetchIvrPrompts = async () => {
    setLoadingPrompts(true);
    const { data, error } = await supabase.from('ivr_prompts').select('*').order('name', { ascending: true });
    if (error) {
      toast({ title: "Error fetching IVR prompts", description: error.message, variant: "destructive" });
      setPrompts([]);
    } else {
      setPrompts(data || []);
    }
    setLoadingPrompts(false);
  };

  const fetchVoicemailsAndUsers = async () => {
    setLoadingVoicemails(true);
    // Fetch users first to create a map
    const { data: usersData, error: usersError } = await supabase.from('users').select('id, full_name, email');
    if (usersError) {
      toast({ title: "Error fetching users for voicemails", description: usersError.message, variant: "destructive" });
    } else {
      const map = (usersData || []).reduce((acc, user) => {
        acc[user.id] = user.full_name || user.email;
        return acc;
      }, {});
      setUsersMap(map);
    }

    // Fetch voicemails
    // Simplified the select query for call_logs. We will map user details on client if needed.
    const { data, error } = await supabase.from('voicemails')
      .select(`
        *, 
        call_logs (id, caller_number, user_id) 
      `)
      .order('created_at', { ascending: false });
    if (error) {
      toast({ title: "Error fetching voicemails", description: error.message, variant: "destructive" });
      setVoicemails([]);
    } else {
      // Manually add user_full_name to voicemails if call_log.user_id exists
      const enrichedVoicemails = (data || []).map(vm => {
        let assignedUserName = 'System';
        if (vm.call_logs && vm.call_logs.user_id && usersMap[vm.call_logs.user_id]) {
          assignedUserName = usersMap[vm.call_logs.user_id];
        } else if (vm.user_id && usersMap[vm.user_id]) { // Voicemail directly assigned to a user
           assignedUserName = usersMap[vm.user_id];
        }
        return { ...vm, assigned_user_name: assignedUserName };
      });
      setVoicemails(enrichedVoicemails);
    }
    setLoadingVoicemails(false);
  };
  
  const handlePlayVoicemail = (voicemail) => {
    setVoicemails(prev => prev.map(vm => vm.id === voicemail.id ? {...vm, is_listened: true} : vm));
    
    supabase.from('voicemails').update({ is_listened: true }).eq('id', voicemail.id).then(({error}) => {
        if (error) toast({title: "Error updating voicemail status", description: error.message, variant: "destructive"});
    });
    toast({
      title: "Playing Voicemail (Simulated)",
      description: `Simulating playback for voicemail from ${voicemail.call_logs?.caller_number || voicemail.caller_number}. URL: ${voicemail.recording_url}`,
    });
  };

  const handleDeleteVoicemail = async (voicemailId) => {
    const voicemailToDelete = voicemails.find(vm => vm.id === voicemailId);
    if(voicemailToDelete && voicemailToDelete.recording_url && voicemailToDelete.recording_url.startsWith('https://' + supabase.storage.url.split('/')[2])) {
       // Attempt to delete from storage only if it's a Supabase storage URL.
      // Extract path from URL: https://<project_ref>.supabase.co/storage/v1/object/public/<bucket_name>/<path_to_file>
      try {
        const urlParts = new URL(voicemailToDelete.recording_url);
        const pathSegments = urlParts.pathname.split('/');
        // Path is usually after /object/public/<bucket_name>/...
        const bucketName = pathSegments[4]; // This needs to be dynamic if buckets vary
        const filePath = pathSegments.slice(5).join('/');
        
        if (bucketName && filePath) {
            const { error: storageError } = await supabase.storage.from(bucketName).remove([filePath]);
            if (storageError && storageError.statusCode !== '404') {
                toast({ title: "Error deleting audio from storage", description: storageError.message, variant: "destructive" });
            }
        }
      } catch(e) {
          console.error("Error parsing storage URL for deletion", e);
      }
    }

    const { error } = await supabase.from('voicemails').delete().eq('id', voicemailId);
    if (error) {
      toast({ title: "Error deleting voicemail from DB", description: error.message, variant: "destructive" });
    } else {
      toast({ title: "Voicemail deleted" });
      fetchVoicemailsAndUsers(); 
    }
  };


  return (
    <div className="space-y-8">
      <motion.h1 
        className="text-4xl font-bold text-gradient flex items-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Briefcase className="mr-3 h-10 w-10" /> IVR Configuration & Voicemail
      </motion.h1>
      <p className="text-lg text-gray-400">
        Manage custom audio prompts for IVR systems, general greetings, and voicemails. These prompts are stored in Supabase Storage and linked in the 'ivr_prompts' table.
      </p>

      <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
        <Card className="donation-card">
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle className="text-xl text-white flex items-center"><ListTree className="mr-2 h-5 w-5 text-sky-400"/>IVR Audio Prompts</CardTitle>
              <CardDescription className="text-gray-400">Manage audio files for call flows. Uploaded to Supabase Storage.</CardDescription>
            </div>
          </CardHeader>
          <CardContent>
            <IvrPromptsManager 
              prompts={prompts} 
              fetchIvrPrompts={fetchIvrPrompts} 
              loading={loadingPrompts}
            />
          </CardContent>
        </Card>
      </motion.div>

      <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
        <Card className="donation-card">
          <CardHeader>
            <CardTitle className="text-xl text-white flex items-center"><VoicemailIcon className="mr-2 h-6 w-6 text-yellow-400" /> Voicemail Management</CardTitle>
            <CardDescription className="text-gray-400">Access and manage voicemail messages. Fetched from 'voicemails' table.</CardDescription>
          </CardHeader>
          <CardContent>
             <VoicemailManager
                voicemails={voicemails}
                loading={loadingVoicemails}
                onPlayVoicemail={handlePlayVoicemail}
                onDeleteVoicemail={handleDeleteVoicemail}
             />
          </CardContent>
        </Card>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <ConferenceCallSimulator />
      </motion.div>
    </div>
  );
};

export default CallManagementPage;
