
import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { PhoneCall, Headphones, CheckCircle, AlertCircle, ChevronRight, XCircle, Info, ExternalLink, ListTree, Play, Pause, Settings as SettingsIcon } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';

const IVR_STEPS = {
  IDLE: 'IDLE',
  WELCOME: 'WELCOME',
  MAIN_MENU: 'MAIN_MENU',
  SALES: 'SALES',
  SUPPORT: 'SUPPORT',
  GENERAL_INFO: 'GENERAL_INFO',
  VOICEMAIL_PROMPT: 'VOICEMAIL_PROMPT',
  VOICEMAIL_RECORDING: 'VOICEMAIL_RECORDING',
  OPERATOR_TRANSFER: 'OPERATOR_TRANSFER',
  INVALID_OPTION: 'INVALID_OPTION',
  CALL_ENDED: 'CALL_ENDED',
};

const IvrSystemPage = ({ user: currentUser }) => {
  const [currentStep, setCurrentStep] = useState(IVR_STEPS.IDLE);
  const [isCallActive, setIsCallActive] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [callId, setCallId] = useState(null);
  const audioRef = useRef(null);
  const [edgeFunctionUrl, setEdgeFunctionUrl] = useState('');
  const [audioPlaying, setAudioPlaying] = useState(false);
  const [attempts, setAttempts] = useState(0);
  const [ivrScripts, setIvrScripts] = useState({}); // Will hold prompt URLs

  useEffect(() => {
    const projectRef = 'vjfppgynkgysliadpfvt'; 
    setEdgeFunctionUrl(`https://${projectRef}.supabase.co/functions/v1/twilio-general-ivr`);
    fetchIvrPrompts();
  }, []);

  const fetchIvrPrompts = async () => {
    // Fetch prompts from 'ivr_prompts' table and map them for IVR_SCRIPTS
    const { data, error } = await supabase.from('ivr_prompts').select('name, audio_url, supabase_storage_path');
    if (error) {
      toast({ title: "Error fetching IVR prompts", description: error.message, variant: "destructive" });
      return;
    }
    const scripts = {};
    // This mapping needs to be more robust, linking DB prompt names to IVR_SCRIPT keys
    // For now, using a simplified mapping based on common names in `initialGreetings` on CallManagementPage
    const promptMap = {
      'GENERAL_IVR_GREETING_MP3': 'WELCOME',
      'GENERAL_IVR_MAIN_MENU_MP3': 'MAIN_MENU',
      'GENERAL_IVR_SALES_INFO_MP3': 'GENERAL_INFO', // Example mapping
      'GENERAL_IVR_VOICEMAIL_PROMPT_MP3': 'VOICEMAIL_PROMPT',
      'GENERAL_IVR_INVALID_OPTION_MP3': 'INVALID_OPTION'
    };

    const baseScripts = {
      [IVR_STEPS.WELCOME]: { text: "Welcome to our company. Please listen carefully to the following options.", audioKey: 'GENERAL_IVR_GREETING_MP3' },
      [IVR_STEPS.MAIN_MENU]: { text: "Press 1 for Sales, 2 for Support, 3 for General Information, 4 to leave a voicemail, or 0 for an operator.", audioKey: 'GENERAL_IVR_MAIN_MENU_MP3', inputType: 'dtmf', maxLength: 1 },
      [IVR_STEPS.SALES]: { text: "Connecting you to Sales...", audioKey: null, final: true },
      [IVR_STEPS.SUPPORT]: { text: "Connecting you to Support...", audioKey: null, final: true },
      [IVR_STEPS.GENERAL_INFO]: { text: "Playing general information...", audioKey: 'GENERAL_IVR_SALES_INFO_MP3' }, // example audio key
      [IVR_STEPS.VOICEMAIL_PROMPT]: { text: "Please leave your message after the tone. Press pound when finished.", audioKey: 'GENERAL_IVR_VOICEMAIL_PROMPT_MP3' },
      [IVR_STEPS.VOICEMAIL_RECORDING]: { text: "Recording voicemail... (Simulated)", audioKey: null, inputType: 'text', placeholder: "Type your voicemail message" },
      [IVR_STEPS.OPERATOR_TRANSFER]: { text: "Connecting you to an operator...", audioKey: null, final: true },
      [IVR_STEPS.INVALID_OPTION]: { text: "That was not a valid option. Please try again.", audioKey: 'GENERAL_IVR_INVALID_OPTION_MP3' },
      [IVR_STEPS.CALL_ENDED]: { text: "Thank you for calling. Goodbye.", audioKey: null, final: true },
    };
    
    data.forEach(prompt => {
        for (const [scriptKey, stepKey] of Object.entries(promptMap)) {
            if (prompt.supabase_storage_path.includes(scriptKey) || prompt.name.includes(scriptKey.replace('_MP3','').replace(/_/g, ' '))) {
                 if(baseScripts[stepKey]) {
                    baseScripts[stepKey].audioUrl = prompt.audio_url;
                 }
            }
        }
    });
    setIvrScripts(baseScripts);
  };

  const currentScript = ivrScripts[currentStep];

  const playAudio = () => {
    if (currentScript?.audioUrl && audioRef.current) {
      audioRef.current.src = currentScript.audioUrl;
      audioRef.current.play()
        .then(() => setAudioPlaying(true))
        .catch(e => console.warn("Audio playback prevented:", e));
    } else if (currentScript?.audioKey) {
         toast({title: "Missing Audio", description: `Prompt for ${currentScript.audioKey} not found or URL invalid. Using text only.`, variant: "destructive"});
    }
  };

  const stopAudio = () => {
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
      setAudioPlaying(false);
    }
  };

  useEffect(() => {
    stopAudio();
    if (isCallActive && currentScript?.audioUrl) {
      playAudio();
    } else if (isCallActive && currentScript?.audioKey && !currentScript?.audioUrl) {
       toast({title: "Audio Not Loaded", description: `Audio for ${currentScript.audioKey} is configured but URL is missing. Playing text only.`, variant: "destructive"});
    }
  }, [currentStep, currentScript, isCallActive]);

  const logSimulatedIvrEvent = async (callId, eventType, eventData) => {
    try {
      const { error } = await supabase
        .from('call_events')
        .insert([{ 
            timestamp: new Date().toISOString(),
            event_source: 'frontend_simulation',
            event_type: `sim-general-ivr-${eventType}`, 
            call_sid: callId, // Using callId as call_sid for simulation
            user_id: currentUser.id, 
            event_data: eventData, 
            notes: 'Frontend IVR Simulation' 
        }]);
      if (error) throw error;
    } catch (error) {
      console.error('Error logging simulated IVR event:', error.message);
    }
  };

  const startCall = () => {
    const newCallId = `sim-ivr-${Date.now()}`;
    setCallId(newCallId);
    setIsCallActive(true);
    setCurrentStep(IVR_STEPS.WELCOME);
    setInputValue('');
    setAttempts(0);
    logSimulatedIvrEvent(newCallId, 'call-started', {});
    setTimeout(() => setCurrentStep(IVR_STEPS.MAIN_MENU), 3000);
  };

  const endCall = (reason = 'user_ended') => {
    setIsCallActive(false);
    setCurrentStep(IVR_STEPS.CALL_ENDED);
    logSimulatedIvrEvent(callId, 'call-ended', { reason });
    stopAudio();
    setTimeout(() => setCurrentStep(IVR_STEPS.IDLE), 3000);
  };

  const handleInputChange = (e) => setInputValue(e.target.value);

  const handleSubmitInput = () => {
    logSimulatedIvrEvent(callId, 'dtmf-input', { step: currentStep, value: inputValue });
    const currentAttempts = attempts;
    setAttempts(prev => prev + 1);

    if (currentStep === IVR_STEPS.MAIN_MENU) {
      switch (inputValue) {
        case '1': setCurrentStep(IVR_STEPS.SALES); break;
        case '2': setCurrentStep(IVR_STEPS.SUPPORT); break;
        case '3': setCurrentStep(IVR_STEPS.GENERAL_INFO); setTimeout(() => setCurrentStep(IVR_STEPS.MAIN_MENU), 5000); break;
        case '4': setCurrentStep(IVR_STEPS.VOICEMAIL_PROMPT); setTimeout(() => setCurrentStep(IVR_STEPS.VOICEMAIL_RECORDING), 3000); break;
        case '0': setCurrentStep(IVR_STEPS.OPERATOR_TRANSFER); break;
        default:
          if (currentAttempts >= 1) { 
            setCurrentStep(IVR_STEPS.OPERATOR_TRANSFER);
            toast({ title: "Max Attempts Reached", description: "Transferring to operator.", variant: "destructive" });
          } else {
            setCurrentStep(IVR_STEPS.INVALID_OPTION);
            setTimeout(() => setCurrentStep(IVR_STEPS.MAIN_MENU), 3000);
          }
          break;
      }
    } else if (currentStep === IVR_STEPS.VOICEMAIL_RECORDING) {
      logSimulatedIvrEvent(callId, 'voicemail-left', { message: inputValue });
      toast({ title: "Voicemail Sent (Simulated)", description: "Your message has been recorded." });
      // Simulate saving voicemail to DB
      supabase.from('voicemails').insert({
        call_log_id: null, // No real call_log for pure simulation, or create one
        caller_number: 'SIMULATED_CALLER',
        recording_url: 'simulated_voicemail.mp3', // Placeholder
        transcription: inputValue,
        mailbox: 'general_simulation',
      }).then(({error}) => {
        if(error) console.error("Error saving simulated voicemail", error)
      });
      endCall('voicemail_complete');
    }
    setInputValue('');
    if (ivrScripts[currentStep]?.final) setTimeout(() => endCall('flow_complete'), 4000);
  };
  
  const renderCallStepUI = () => {
    if (!isCallActive && currentStep === IVR_STEPS.IDLE) {
      return (
        <Button onClick={startCall} className="w-full bg-teal-600 hover:bg-teal-700 text-white py-3 text-lg" size="lg">
          <PhoneCall className="w-5 h-5 mr-2" /> Start General IVR Simulation
        </Button>
      );
    }

    if (Object.keys(ivrScripts).length === 0) {
        return <p className="text-yellow-400 text-center py-4">Loading IVR scripts or no prompts configured...</p>;
    }
    if (!currentScript) {
        return <p className="text-red-400 text-center py-4">Error: IVR script for current step ({currentStep}) not found.</p>;
    }


    return (
      <div className="space-y-4 p-4 bg-slate-700/50 rounded-lg">
        <div className="flex items-center text-lg font-semibold text-teal-400">
          <Headphones className="w-6 h-6 mr-2 animate-pulse" />
          IVR Call Active... (ID: {callId})
        </div>
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-sky-400">IVR Script:</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-white text-lg min-h-[60px]">{currentScript?.text}</p>
            {(currentScript?.audioUrl || currentScript?.audioKey) && (
              <div className="mt-2">
                <audio ref={audioRef} className="hidden" onEnded={() => setAudioPlaying(false)} />
                <Button variant="outline" size="sm" onClick={() => audioPlaying ? stopAudio() : playAudio()} className="text-sky-300 border-sky-700 hover:bg-sky-700/50">
                  {audioPlaying ? <Pause className="w-4 h-4 mr-1" /> : <Play className="w-4 h-4 mr-1" />}
                  {audioPlaying ? 'Pause Prompt' : 'Play Prompt'} ({currentScript.audioKey || 'Custom Audio'})
                </Button>
                 {!currentScript.audioUrl && currentScript.audioKey && <p className="text-xs text-yellow-500 mt-1">Audio URL for {currentScript.audioKey} not found. Configure in IVR Prompts.</p>}
              </div>
            )}
          </CardContent>
        </Card>

        {currentScript?.inputType === 'dtmf' && (
          <div className="space-y-2">
            <Label htmlFor="dtmfInput" className="text-gray-300">Enter Option (Simulated DTMF):</Label>
            <div className="flex space-x-2">
              <Input id="dtmfInput" type="text" pattern="[0-9*#]" value={inputValue} onChange={handleInputChange} maxLength={currentScript.maxLength} className="bg-slate-600 border-slate-500 text-white placeholder-slate-400 text-lg" placeholder="e.g., 1"/>
              <Button onClick={handleSubmitInput} className="bg-sky-600 hover:bg-sky-700 text-white">Send <ChevronRight className="w-4 h-4 ml-1" /></Button>
            </div>
          </div>
        )}
        {currentScript?.inputType === 'text' && (
           <div className="space-y-2">
            <Label htmlFor="textInput" className="text-gray-300">{currentScript.placeholder || "Enter message"}:</Label>
            <div className="flex space-x-2">
              <Input id="textInput" type="text" value={inputValue} onChange={handleInputChange} className="bg-slate-600 border-slate-500 text-white placeholder-slate-400 text-lg" placeholder={currentScript.placeholder}/>
              <Button onClick={handleSubmitInput} className="bg-sky-600 hover:bg-sky-700 text-white">Send <ChevronRight className="w-4 h-4 ml-1" /></Button>
            </div>
          </div>
        )}

        {currentStep !== IVR_STEPS.IDLE && !currentScript?.final && (
          <Button onClick={() => endCall('user_hung_up')} variant="destructive" className="w-full mt-4">
            <XCircle className="w-4 h-4 mr-1" /> End Call
          </Button>
        )}
         {currentScript?.final && (
          <p className="text-center text-green-400 font-semibold py-2">Call concluding...</p>
        )}
      </div>
    );
  };

  return (
    <div className="space-y-8">
      <motion.h1 className="text-4xl font-bold text-gradient flex items-center" initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <ListTree className="mr-3 h-10 w-10" /> General Inquiry IVR System
      </motion.h1>
      
      <Card className="donation-card bg-sky-600/10 border-sky-500/50">
        <CardHeader>
          <CardTitle className="text-xl text-sky-300 flex items-center"><Info className="w-5 h-5 mr-2"/>Twilio Integration for General IVR</CardTitle>
        </CardHeader>
        <CardContent className="text-sky-200 space-y-2">
          <p>This IVR is designed for general inquiries and call routing. Configure your Twilio phone number's voice webhook to point to:</p>
          <div className="p-2 bg-slate-900/50 rounded font-mono text-sm break-all flex items-center">
            {edgeFunctionUrl ? edgeFunctionUrl : "Loading URL..."}
            {edgeFunctionUrl && <Button variant="ghost" size="sm" className="ml-2 text-sky-300 hover:text-sky-200" onClick={() => navigator.clipboard.writeText(edgeFunctionUrl).then(() => toast({title: "URL Copied!"}))}>Copy URL</Button>}
          </div>
          <p className="text-xs">The Edge Function handles the live call flow. Audio prompts are fetched from the 'ivr_prompts' table in Supabase using their `audio_url`. Ensure prompts are uploaded to Supabase Storage and URLs are correct in the table. The Edge function uses ENV VARS which should point to these DB records or specific URLs.</p>
          <a href="https://www.twilio.com/docs/voice/tutorials/how-to-respond-to-incoming-phone-calls" target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-sky-300 hover:text-sky-100 underline">
            Twilio Webhook Guide <ExternalLink className="w-4 h-4 ml-1" />
          </a>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
          <Card className="donation-card min-h-[300px]">
            <CardHeader>
              <CardTitle className="text-xl text-white">Simulate General IVR Call</CardTitle>
              <CardDescription className="text-gray-400">Test the general inquiry IVR flow locally.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {renderCallStepUI()}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }}>
          <Card className="donation-card">
            <CardHeader>
              <CardTitle className="text-xl text-white">IVR Flow Overview</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
            {Object.entries(ivrScripts)
              .filter(([key]) => ![IVR_STEPS.IDLE, IVR_STEPS.CALL_ENDED, IVR_STEPS.INVALID_OPTION].includes(key) && ivrScripts[key]?.text) // Filter out helper/final steps
              .map(([key, scriptData]) => (
                <div key={key} className={`flex items-center space-x-3 p-2 rounded-md ${isCallActive && currentStep === key ? 'bg-sky-600/30 ring-2 ring-sky-500' : 'bg-slate-700/50'}`}>
                  <ListTree className={`w-5 h-5 ${isCallActive && currentStep === key ? 'text-sky-400 animate-pulse' : 'text-gray-400'}`} />
                  <span className={`${isCallActive && currentStep === key ? 'text-sky-300 font-semibold' : 'text-gray-300'}`}>{scriptData.text.substring(0,30)}{scriptData.text.length > 30 ? '...' : ''} ({key})</span>
                </div>
            ))}
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default IvrSystemPage;
