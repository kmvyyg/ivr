import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { MessageSquare, Send, CheckCircle, AlertCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { toast } from '@/components/ui/use-toast';

const SmsSystemPage = () => {
  const [smsMessages, setSmsMessages] = useState([]);
  const [donationAmount, setDonationAmount] = useState('');
  const [totalSmsDonations, setTotalSmsDonations] = useState(0); // Local state

  const simulateSMS = () => {
    const amount = donationAmount || '10';
    if (isNaN(parseInt(amount)) || parseInt(amount) <= 0) {
      toast({
        title: "Invalid Amount",
        description: "Please enter a valid donation amount.",
        variant: "destructive",
        action: <AlertCircle className="text-red-500" />,
      });
      return;
    }

    const newMessage = {
      id: Date.now(),
      text: `DONATE ${amount}`,
      response: `Thank you! Your $${amount} donation has been processed. Reply STOP to opt out.`,
      timestamp: new Date().toLocaleTimeString(),
      type: 'sent'
    };
    const responseMessage = {
      id: Date.now() + 1,
      text: newMessage.response,
      timestamp: new Date().toLocaleTimeString(),
      type: 'received'
    }
    
    setSmsMessages(prev => [responseMessage, newMessage, ...prev]);
    setDonationAmount('');
    setTotalSmsDonations(prev => prev + parseInt(amount));
    
    toast({
      title: "SMS Donation Sent!",
      description: `$${amount} donation processed via SMS (simulation).`,
      action: <CheckCircle className="text-green-500" />,
    });
  };

  return (
    <div className="space-y-8">
      <motion.h1 
        className="text-4xl font-bold text-gradient"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        SMS Donation System
      </motion.h1>
      <p className="text-lg text-gray-400">
        Simulate sending and receiving SMS donations. Test keywords and automated responses.
      </p>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <Card className="donation-card">
            <CardHeader>
              <CardTitle className="text-xl text-white">Simulate SMS Donation</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div>
                <label htmlFor="smsAmount" className="block text-sm font-medium text-gray-300 mb-1">
                  Donation Amount ($)
                </label>
                <Input
                  id="smsAmount"
                  type="number"
                  value={donationAmount}
                  onChange={(e) => setDonationAmount(e.target.value)}
                  placeholder="e.g., 25"
                  className="bg-slate-700 border-slate-600 placeholder-slate-400"
                />
              </div>
              
              <div className="p-3 bg-slate-700/50 rounded-lg">
                <p className="text-sm text-gray-400 mb-1">SMS Preview (to +1 555 DONATE):</p>
                <p className="text-white font-mono">DONATE {donationAmount || '{amount}'}</p>
              </div>

              <Button
                onClick={simulateSMS}
                className="w-full bg-blue-600 hover:bg-blue-700 text-white py-3 text-lg"
                size="lg"
              >
                <Send className="w-5 h-5 mr-2" />
                Send SMS Donation
              </Button>
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <Card className="donation-card">
            <CardHeader>
              <CardTitle className="text-xl text-white">SMS Message Log</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 max-h-96 overflow-y-auto p-4 bg-slate-800/50 rounded-lg">
              {smsMessages.length === 0 ? (
                <div className="text-center text-gray-400 py-8">
                  <MessageSquare className="w-12 h-12 mx-auto mb-3 opacity-50" />
                  <p>No SMS messages yet.</p>
                  <p className="text-sm">Send a test donation to see it here.</p>
                </div>
              ) : (
                smsMessages.map((message) => (
                  <div
                    key={message.id}
                    className={`p-3 rounded-lg max-w-[80%] ${
                      message.type === 'sent' 
                        ? 'bg-blue-600 ml-auto text-right' 
                        : 'bg-slate-600 mr-auto text-left'
                    }`}
                  >
                    <p className="text-white text-sm">{message.text}</p>
                    <p className="text-xs text-gray-300 mt-1">{message.timestamp}</p>
                  </div>
                ))
              )}
            </CardContent>
          </Card>
        </motion.div>
      </div>

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        transition={{ delay: 0.2 }}
      >
        <Card className="donation-card">
          <CardHeader>
            <CardTitle className="text-xl text-white">SMS Keywords & Configuration</CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <p className="text-gray-400">Commonly configured SMS keywords:</p>
            <div className="flex flex-wrap gap-3">
              {['DONATE [amount]', 'HELP', 'STOP', 'INFO', 'PLEDGE [amount]'].map(keyword => (
                <span key={keyword} className="px-3 py-1 bg-slate-700 text-slate-300 rounded-full text-sm font-mono">
                  {keyword}
                </span>
              ))}
            </div>
            <div className="mt-4 p-3 bg-purple-600/20 rounded-lg flex items-start space-x-3">
              <AlertCircle className="w-5 h-5 text-purple-400 mt-1 flex-shrink-0" />
              <p className="text-sm text-purple-300">
                SMS functionality requires integration with a provider like Twilio. Keywords and responses are configured within their platform or via API.
              </p>
            </div>
            <Button variant="outline" className="border-purple-500 text-purple-400 hover:bg-purple-500/20 hover:text-purple-300">
              Manage SMS Settings (Coming Soon)
            </Button>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default SmsSystemPage;