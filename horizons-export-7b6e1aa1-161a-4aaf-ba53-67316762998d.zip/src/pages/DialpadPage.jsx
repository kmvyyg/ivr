
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { PhoneOutgoing, PhoneOff, PhoneCall as PhoneCallIcon, User, Delete, History, CheckCircle, AlertTriangle, MessageCircle } from 'lucide-react';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';

const DialpadButton = ({ digit, letters, onClick, onLongPress, className }) => {
  let pressTimer;

  const handleMouseDown = () => {
    pressTimer = setTimeout(onLongPress, 600); 
  };

  const handleMouseUp = () => {
    clearTimeout(pressTimer);
  };

  const handleTouchStart = () => {
    pressTimer = setTimeout(onLongPress, 600);
  };

  const handleTouchEnd = () => {
    clearTimeout(pressTimer);
  };

  return (
    <Button
      variant="outline"
      className={`dialpad-button h-20 w-20 text-3xl flex flex-col items-center justify-center rounded-full bg-slate-700/60 hover:bg-slate-600/80 border-slate-600/80 text-white shadow-md transition-all duration-150 active:scale-95 ${className}`}
      onClick={() => onClick(digit)}
      onMouseDown={onLongPress ? handleMouseDown : null}
      onMouseUp={onLongPress ? handleMouseUp : null}
      onTouchStart={onLongPress ? handleTouchStart : null}
      onTouchEnd={onLongPress ? handleTouchEnd : null}
    >
      <span>{digit}</span>
      {letters && <span className="text-xs tracking-wider opacity-70">{letters}</span>}
    </Button>
  );
};

const DialpadPage = ({ user: currentUser }) => {
  const [phoneNumber, setPhoneNumber] = useState('');
  const [isCallActive, setIsCallActive] = useState(false);
  const [callStatus, setCallStatus] = useState('');
  const [callDuration, setCallDuration] = useState(0);
  const [callTimerInterval, setCallTimerInterval] = useState(null);
  const [recentCalls, setRecentCalls] = useState([]);
  const [contacts, setContacts] = useState([]);
  const [selectedContact, setSelectedContact] = useState('none');
  const [availableOutboundNumbers, setAvailableOutboundNumbers] = useState([]);
  const [selectedOutboundNumber, setSelectedOutboundNumber] = useState('');


  useEffect(() => {
    fetchRecentCalls();
    fetchContacts();
    fetchAvailableOutboundNumbers();
  }, [currentUser.id]);

  const fetchRecentCalls = async () => {
    const { data, error } = await supabase
      .from('call_logs')
      .select('*')
      .eq('user_id', currentUser.id)
      .eq('direction', 'outbound')
      .order('start_time', { ascending: false })
      .limit(5);
    if (error) console.error("Error fetching recent calls:", error);
    else setRecentCalls(data || []);
  };

  const fetchContacts = async () => {
    const { data, error } = await supabase
      .from('contacts')
      .select('id, name, phone_number')
      .eq('user_id', currentUser.id)
      .order('name', { ascending: true });
    if (error) console.error("Error fetching contacts:", error);
    else setContacts(data || []);
  };

  const fetchAvailableOutboundNumbers = async () => {
    let query = supabase.from('phone_numbers').select('id, phone_number, friendly_name')
                        .eq('capabilities->>voice', 'true'); // Only fetch voice enabled numbers
    
    // If user is not admin, try to find numbers assigned to them first
    if(currentUser.role !== 'admin'){
      query = query.eq('user_id', currentUser.id);
    }
    
    const { data, error } = await query.order('friendly_name', {ascending: true});

    if (error) {
      toast({title: "Error Fetching Caller IDs", description: error.message, variant: "destructive"});
      setAvailableOutboundNumbers([]);
    } else {
      setAvailableOutboundNumbers(data || []);
      if (data && data.length > 0) {
        // Set default caller ID: first assigned to user, or first in list if admin
        const userSpecificNumber = data.find(n => n.user_id === currentUser.id);
        setSelectedOutboundNumber(userSpecificNumber ? userSpecificNumber.phone_number : data[0].phone_number);
      } else if (currentUser.role === 'admin' && data.length === 0){
          // If admin and no numbers for self, try fetching any number
          const { data: allNumbers, error: allError } = await supabase.from('phone_numbers')
            .select('id, phone_number, friendly_name')
            .eq('capabilities->>voice', 'true')
            .order('friendly_name', {ascending: true});

          if (!allError && allNumbers && allNumbers.length > 0) {
            setAvailableOutboundNumbers(allNumbers);
            setSelectedOutboundNumber(allNumbers[0].phone_number);
          } else {
            setSelectedOutboundNumber('');
          }
      } else {
          setSelectedOutboundNumber('');
      }
    }
  };


  const handleDigitClick = (digit) => {
    if (isCallActive) return; 
    setPhoneNumber(prev => prev + digit);
  };
  
  const handlePlusLongPress = () => {
     if (isCallActive) return;
     setPhoneNumber(prev => '+' + prev.replace(/\+/g, ''));
  };

  const handleDelete = () => {
    if (isCallActive) return;
    setPhoneNumber(prev => prev.slice(0, -1));
  };

  const handleCall = async () => {
    if (!phoneNumber.trim()) {
      toast({ title: "Enter Number", description: "Please enter a phone number to call.", variant: "destructive", icon: <AlertTriangle className="h-5 w-5"/> });
      return;
    }
    if (!selectedOutboundNumber) {
        toast({ title: "No Outbound Number", description: "Please select or configure a Caller ID.", variant: "destructive", icon: <AlertTriangle className="h-5 w-5"/> });
        return;
    }

    setIsCallActive(true);
    setCallStatus('Dialing...');
    
    const { data: callLogData, error: logError } = await supabase
      .from('call_logs')
      .insert({
        user_id: currentUser.id,
        direction: 'outbound',
        status: 'initiated', 
        external_party_number: phoneNumber,
        phone_number_id: availableOutboundNumbers.find(n => n.phone_number === selectedOutboundNumber)?.id || null,
        start_time: new Date().toISOString(),
      })
      .select()
      .single();

    if (logError) {
      toast({ title: "Call Logging Error", description: logError.message, variant: "destructive", icon: <AlertTriangle className="h-5 w-5"/> });
      setIsCallActive(false);
      setCallStatus('');
      return;
    }

    // Simulate call connection
    setTimeout(() => {
      setCallStatus('Connected');
      const timer = setInterval(() => setCallDuration(d => d + 1), 1000);
      setCallTimerInterval(timer);
      supabase.from('call_logs').update({ status: 'answered', answer_time: new Date().toISOString() }).eq('id', callLogData.id).then();
      toast({ title: "Call Connected (Simulated)", description: `Call to ${phoneNumber} is live.`, icon: <CheckCircle className="h-5 w-5 text-green-500"/>});
    }, 2000 + Math.random() * 1500); // Random delay for simulation

  };

  const handleEndCall = async () => {
    setIsCallActive(false);
    setCallStatus('Call Ended');
    clearInterval(callTimerInterval);
    
    const { data: callLogDataArray } = await supabase
      .from('call_logs')
      .select('id, start_time')
      .match({ user_id: currentUser.id, external_party_number: phoneNumber, status: 'answered' }) 
      .order('start_time', { ascending: false })
      .limit(1);

    const callLogData = callLogDataArray && callLogDataArray.length > 0 ? callLogDataArray[0] : null;

    if (callLogData) {
      await supabase
        .from('call_logs')
        .update({ 
            status: 'completed', 
            end_time: new Date().toISOString(),
            duration_seconds: callDuration
        })
        .eq('id', callLogData.id);
    }
    
    toast({ title: "Call Ended", description: `Duration: ${formatDuration(callDuration)}`, icon: <MessageCircle className="h-5 w-5 text-blue-500"/> });
    setCallDuration(0);
    setPhoneNumber(''); 
    fetchRecentCalls(); 
  };

  const formatDuration = (seconds) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const dialpadLayout = [
    { digit: '1', letters: '' }, { digit: '2', letters: 'ABC' }, { digit: '3', letters: 'DEF' },
    { digit: '4', letters: 'GHI' }, { digit: '5', letters: 'JKL' }, { digit: '6', letters: 'MNO' },
    { digit: '7', letters: 'PQRS' }, { digit: '8', letters: 'TUV' }, { digit: '9', letters: 'WXYZ' },
    { digit: '*', letters: '' }, { digit: '0', letters: '+', onLongPress: handlePlusLongPress }, { digit: '#', letters: '' },
  ];
  
  useEffect(() => {
      if(selectedContact && selectedContact !== 'none') {
          const contact = contacts.find(c => c.id === selectedContact);
          if(contact) setPhoneNumber(contact.phone_number);
      } else if (selectedContact === 'none') {
          setPhoneNumber('');
      }
  }, [selectedContact, contacts]);


  return (
    <div className="space-y-8 max-w-md mx-auto">
      <motion.div 
        className="text-center"
        initial={{ opacity: 0, y: -30 }} 
        animate={{ opacity: 1, y: 0 }}
        transition={{ type: "spring", stiffness: 100 }}
      >
        <div className="inline-block p-4 bg-gradient-to-br from-green-500 to-blue-600 rounded-full shadow-lg mb-3">
          <PhoneOutgoing className="h-10 w-10 text-white" />
        </div>
        <h1 className="text-4xl font-bold text-gradient">Dialpad</h1>
      </motion.div>

      <Card className="donation-card p-4 sm:p-6 shadow-2xl">
        <CardHeader className="pb-3 pt-2">
          <CardTitle className="text-center text-2xl text-slate-100">Place a Call</CardTitle>
        </CardHeader>
        <CardContent className="flex flex-col items-center space-y-5">
          <div className="w-full space-y-1.5">
            <Label htmlFor="outboundNumberSelect" className="text-slate-300">Your Caller ID:</Label>
            <Select value={selectedOutboundNumber} onValueChange={setSelectedOutboundNumber} disabled={isCallActive}>
              <SelectTrigger id="outboundNumberSelect" className="bg-slate-700/80 border-slate-600 text-white h-12 text-base">
                <SelectValue placeholder="Select Caller ID" />
              </SelectTrigger>
              <SelectContent className="bg-slate-800 border-slate-700 text-white">
                {availableOutboundNumbers.length === 0 && <SelectItem value="no-numbers" disabled>No Caller IDs available</SelectItem>}
                {availableOutboundNumbers.map(num => (
                  <SelectItem key={num.id} value={num.phone_number} className="text-base py-2">
                    {num.friendly_name ? `${num.friendly_name} (${num.phone_number})` : num.phone_number}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="w-full space-y-1.5">
             <Label htmlFor="contactSelect" className="text-slate-300">Or Select Contact:</Label>
             <Select value={selectedContact} onValueChange={setSelectedContact} disabled={isCallActive}>
                <SelectTrigger id="contactSelect" className="bg-slate-700/80 border-slate-600 text-white h-12 text-base">
                    <SelectValue placeholder="Select contact" />
                </SelectTrigger>
                <SelectContent className="bg-slate-800 border-slate-700 text-white">
                     <SelectItem value="none" className="text-base py-2">None</SelectItem>
                    {contacts.map(c => <SelectItem key={c.id} value={c.id} className="text-base py-2">{c.name} ({c.phone_number})</SelectItem>)}
                </SelectContent>
            </Select>
          </div>
          
          <div className="relative w-full">
            <Input
              type="tel"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              placeholder="Enter number to call"
              className="text-3xl h-16 text-center bg-slate-700/80 border-slate-600 text-white placeholder-slate-400 focus:border-green-500 pr-12 shadow-inner"
              disabled={isCallActive}
            />
            {phoneNumber && !isCallActive && (
              <Button variant="ghost" size="icon" className="absolute right-2 top-1/2 -translate-y-1/2 h-12 w-12 text-slate-400 hover:text-slate-200" onClick={handleDelete}>
                <Delete className="h-6 w-6" />
              </Button>
            )}
          </div>

          {isCallActive && (
            <motion.div 
              className="text-center my-3 p-3 bg-slate-700/50 rounded-lg"
              initial={{ opacity: 0, height: 0 }}
              animate={{ opacity: 1, height: 'auto' }}
            >
              <p className="text-lg text-yellow-400 animate-pulse">{callStatus}</p>
              <p className="text-4xl font-mono text-white tracking-wider">{formatDuration(callDuration)}</p>
            </motion.div>
          )}

          <div className="grid grid-cols-3 gap-4 w-full pt-2">
            {dialpadLayout.map(item => (
              <DialpadButton key={item.digit} digit={item.digit} letters={item.letters} onClick={handleDigitClick} onLongPress={item.onLongPress}/>
            ))}
          </div>
          
          <div className="flex space-x-4 w-full pt-3">
            {isCallActive ? (
              <Button className="w-full bg-gradient-to-r from-red-500 to-pink-600 hover:from-red-600 hover:to-pink-700 text-white py-4 text-xl shadow-lg transition-all duration-150 active:scale-95" onClick={handleEndCall}>
                <PhoneOff className="w-7 h-7 mr-2" /> End Call
              </Button>
            ) : (
              <Button className="w-full bg-gradient-to-r from-green-500 to-teal-600 hover:from-green-600 hover:to-teal-700 text-white py-4 text-xl shadow-lg transition-all duration-150 active:scale-95" onClick={handleCall} disabled={!phoneNumber.trim() || !selectedOutboundNumber}>
                <PhoneCallIcon className="w-7 h-7 mr-2" /> Call
              </Button>
            )}
          </div>
        </CardContent>
      </Card>

      <Card className="donation-card shadow-2xl">
        <CardHeader>
          <CardTitle className="text-xl flex items-center text-slate-100"><History className="mr-2 h-6 w-6 text-indigo-400"/>Recent Calls</CardTitle>
        </CardHeader>
        <CardContent>
          {recentCalls.length === 0 ? <p className="text-slate-400 text-center py-4">No recent outbound calls.</p> : (
            <ul className="space-y-3">
              {recentCalls.map(call => (
                <li key={call.id} className="flex justify-between items-center p-3 bg-slate-700/60 rounded-lg shadow">
                  <div>
                    <p className="text-white font-medium">{call.external_party_number}</p>
                    <p className="text-xs text-slate-400">{new Date(call.start_time).toLocaleString()} - {call.status}</p>
                  </div>
                  <Button variant="ghost" size="sm" onClick={() => {setPhoneNumber(call.external_party_number); setSelectedContact('none');}} className="text-green-400 hover:text-green-300 hover:bg-green-500/10">
                    Call Back
                  </Button>
                </li>
              ))}
            </ul>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default DialpadPage;
