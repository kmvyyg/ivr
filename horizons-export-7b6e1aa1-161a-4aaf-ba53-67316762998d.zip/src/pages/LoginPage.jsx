
import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';
import { toast } from '@/components/ui/use-toast';
import { LogIn, Mail, Lock, Briefcase, Eye, EyeOff } from 'lucide-react';
import { motion } from 'framer-motion';

const LoginPage = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [showPassword, setShowPassword] = useState(false);
  const [loading, setLoading] = useState(false);
  const navigate = useNavigate();

  const handleLogin = async (e) => {
    e.preventDefault();
    setLoading(true);
    try {
      const { data, error } = await supabase.auth.signInWithPassword({
        email,
        password,
      });

      if (error) {
        throw error;
      }
      
      if (data.user) {
         toast({
          title: "Login Successful!",
          description: "Welcome back!",
          className: "bg-green-600 border-green-700 text-white",
        });
        navigate('/');
      } else {
         toast({
          title: "Login Failed",
          description: "No user data returned, please check credentials.",
          variant: "destructive",
        });
      }

    } catch (error) {
      toast({
        title: "Login Error",
        description: error.message || "An unexpected error occurred.",
        variant: "destructive",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-slate-900 via-purple-800 to-slate-900 p-4">
      <motion.div
        initial={{ opacity: 0, y: 50, scale: 0.95 }}
        animate={{ opacity: 1, y: 0, scale: 1 }}
        transition={{ duration: 0.6, type: "spring", stiffness: 100 }}
        className="w-full max-w-md"
      >
        <Card className="bg-slate-800/80 backdrop-blur-xl border-slate-700/70 shadow-2xl rounded-xl">
          <CardHeader className="text-center pt-8 pb-6">
            <motion.div 
              className="flex justify-center mb-6"
              initial={{ scale: 0 }}
              animate={{ scale: 1 }}
              transition={{ delay: 0.2, type: "spring", stiffness: 150 }}
            >
              <div className="w-20 h-20 bg-gradient-to-tr from-green-500 via-blue-500 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
                <Briefcase className="w-10 h-10 text-white" />
              </div>
            </motion.div>
            <CardTitle className="text-4xl font-extrabold text-gradient tracking-tight">PhoneSystem Pro</CardTitle>
            <CardDescription className="text-slate-400 text-md pt-1">Securely access your Call Center Dashboard</CardDescription>
          </CardHeader>
          <CardContent className="px-6 sm:px-8 pb-6">
            <form onSubmit={handleLogin} className="space-y-6">
              <div className="space-y-2">
                <Label htmlFor="email" className="text-slate-300 flex items-center text-sm">
                  <Mail className="w-4 h-4 mr-2 text-slate-400" />
                  Email Address
                </Label>
                <Input
                  id="email"
                  type="email"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  placeholder="Enter your email"
                  required
                  className="bg-slate-700/70 border-slate-600/80 text-white placeholder-slate-500 focus:border-purple-500 h-12 text-base rounded-lg shadow-sm"
                />
              </div>
              <div className="space-y-2">
                <Label htmlFor="password" className="text-slate-300 flex items-center text-sm">
                  <Lock className="w-4 h-4 mr-2 text-slate-400" />
                  Password
                </Label>
                <div className="relative">
                  <Input
                    id="password"
                    type={showPassword ? "text" : "password"}
                    value={password}
                    onChange={(e) => setPassword(e.target.value)}
                    placeholder="Enter your password"
                    required
                    className="bg-slate-700/70 border-slate-600/80 text-white placeholder-slate-500 focus:border-purple-500 h-12 text-base rounded-lg shadow-sm pr-10"
                  />
                  <Button
                    type="button"
                    variant="ghost"
                    size="icon"
                    className="absolute right-2 top-1/2 -translate-y-1/2 h-9 w-9 text-slate-400 hover:text-slate-200"
                    onClick={() => setShowPassword(!showPassword)}
                  >
                    {showPassword ? <EyeOff className="h-5 w-5" /> : <Eye className="h-5 w-5" />}
                  </Button>
                </div>
              </div>
              <Button type="submit" className="w-full bg-gradient-to-r from-purple-600 to-blue-600 hover:from-purple-700 hover:to-blue-700 text-white py-3.5 text-lg font-semibold rounded-lg shadow-lg hover:shadow-xl transition-all duration-150 active:scale-[0.98]" disabled={loading}>
                {loading ? (
                  <motion.div
                    animate={{ rotate: 360 }}
                    transition={{ duration: 0.8, repeat: Infinity, ease: "linear" }}
                    className="w-6 h-6 border-2 border-white border-t-transparent rounded-full mr-2"
                  />
                ) : (
                  <LogIn className="w-5 h-5 mr-2" />
                )}
                {loading ? 'Signing In...' : 'Sign In'}
              </Button>
            </form>
          </CardContent>
          <CardFooter className="text-center pb-8 pt-4">
            <p className="text-xs text-slate-500">
              &copy; {new Date().getFullYear()} PhoneSystem Pro. All rights reserved.
            </p>
          </CardFooter>
        </Card>
      </motion.div>
    </div>
  );
};

export default LoginPage;
