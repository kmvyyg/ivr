
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { supabase } from '@/lib/supabaseClient';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from '@/components/ui/use-toast';
import { Users2, PlusCircle, Edit3, Trash2, UserPlus, ShieldCheck } from 'lucide-react';
import { Dialog, DialogContent, DialogDescription, DialogFooter, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog";
import { AlertDialog, AlertDialogAction, AlertDialogCancel, AlertDialogContent, AlertDialogDescription, AlertDialogFooter, AlertDialogHeader, AlertDialogTitle, AlertDialogTrigger } from "@/components/ui/alert-dialog";


const UserManagementPage = ({ user: currentUser }) => {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [showUserDialog, setShowUserDialog] = useState(false);
  const [isEditing, setIsEditing] = useState(false);
  const [currentUserData, setCurrentUserData] = useState({ id: null, email: '', full_name: '', role: 'rep', password: '' });

  useEffect(() => {
    fetchUsers();
  }, []);

  const fetchUsers = async () => {
    setLoading(true);
    const { data, error } = await supabase.from('users').select('*').order('created_at', { ascending: false });
    if (error) {
      toast({ title: "Error fetching users", description: error.message, variant: "destructive" });
    } else {
      setUsers(data);
    }
    setLoading(false);
  };

  const handleInputChange = (e) => {
    const { name, value } = e.target;
    setCurrentUserData(prev => ({ ...prev, [name]: value }));
  };

  const handleRoleChange = (value) => {
    setCurrentUserData(prev => ({ ...prev, role: value }));
  };

  const resetDialog = () => {
    setIsEditing(false);
    setCurrentUserData({ id: null, email: '', full_name: '', role: 'rep', password: '' });
    setShowUserDialog(false);
  };

  const handleAddUser = () => {
    resetDialog();
    setIsEditing(false);
    setShowUserDialog(true);
  };

  const handleEditUser = (user) => {
    setIsEditing(true);
    setCurrentUserData({ id: user.id, email: user.email, full_name: user.full_name || '', role: user.role, password: '' });
    setShowUserDialog(true);
  };

  const handleSubmitUser = async () => {
    if (!currentUserData.email || (!isEditing && !currentUserData.password) || !currentUserData.full_name || !currentUserData.role) {
      toast({ title: "Missing fields", description: "Please fill all required fields.", variant: "destructive" });
      return;
    }

    setLoading(true);
    if (isEditing) {
      // Update existing user
      const updateData = {
        full_name: currentUserData.full_name,
        role: currentUserData.role,
        // email cannot be updated this way easily, Supabase Auth handles email changes with confirmation
      };
      // If password is provided, update it via Supabase Auth (requires admin privileges)
      // This part is complex with Supabase Auth as direct password_hash update is not standard for frontend
      // Typically, you'd use supabase.auth.admin.updateUserById for password changes if you had admin SDK.
      // For simplicity here, we'll update non-auth fields. Password updates require more specific handling.
      
      const { data, error } = await supabase
        .from('users')
        .update(updateData)
        .eq('id', currentUserData.id);
      
      if (error) {
        toast({ title: "Error updating user", description: error.message, variant: "destructive" });
      } else {
        toast({ title: "User updated successfully" });
        fetchUsers();
        resetDialog();
      }

    } else {
      // Create new user via Supabase Auth, then add role to your 'users' table
      const { data: authData, error: authError } = await supabase.auth.signUp({
        email: currentUserData.email,
        password: currentUserData.password,
        options: {
          data: { 
            full_name: currentUserData.full_name,
            // The role will be inserted into the public.users table after successful signup
          }
        }
      });

      if (authError) {
        toast({ title: "Error creating user", description: authError.message, variant: "destructive" });
      } else if (authData.user) {
         // Now insert into your public.users table with the role
        const { error: dbError } = await supabase
          .from('users')
          .update({ 
            role: currentUserData.role,
            full_name: currentUserData.full_name,
            // password_hash should ideally be handled by Supabase Auth triggers or set securely if done manually
            // For this example, we assume Supabase Auth handles password hashing.
            // If your 'users' table has a password_hash, it won't be set here directly from client.
           })
          .eq('id', authData.user.id);

        if (dbError) {
            // Potentially rollback auth user creation or notify admin
            toast({ title: "Auth user created, but DB insert failed", description: dbError.message, variant: "destructive" });
        } else {
            toast({ title: "User created successfully! Confirmation email sent." });
            fetchUsers();
            resetDialog();
        }
      }
    }
    setLoading(false);
  };
  
  const handleDeleteUser = async (userId) => {
    if (userId === currentUser.id) {
      toast({ title: "Cannot delete self", description: "You cannot delete your own account.", variant: "destructive"});
      return;
    }
    setLoading(true);
    // Using supabase.auth.admin.deleteUser requires service_role key, typically on a backend.
    // Simulating deletion from 'users' table only for now. Real deletion needs backend call.
    const { error } = await supabase.from('users').delete().eq('id', userId);
    if (error) {
      toast({ title: "Error deleting user", description: `Simulated delete from 'users' table: ${error.message}`, variant: "destructive" });
    } else {
      toast({ title: "User deleted successfully (from users table)" , description: "Full auth deletion requires backend."});
      fetchUsers();
    }
    setLoading(false);
  };


  return (
    <div className="space-y-8">
      <motion.h1 className="text-4xl font-bold text-gradient flex items-center" initial={{ opacity: 0, y: -20 }} animate={{ opacity: 1, y: 0 }}>
        <Users2 className="mr-3 h-10 w-10" /> User Management
      </motion.h1>
      <p className="text-lg text-gray-400">Administer user accounts, roles, and permissions.</p>

      <Dialog open={showUserDialog} onOpenChange={setShowUserDialog}>
        <DialogTrigger asChild>
          <Button onClick={handleAddUser} className="bg-green-600 hover:bg-green-700">
            <UserPlus className="mr-2 h-5 w-5" /> Add New User
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-md bg-slate-800 border-slate-700 text-white">
          <DialogHeader>
            <DialogTitle className="text-2xl">{isEditing ? 'Edit User' : 'Add New User'}</DialogTitle>
            <DialogDescription className="text-slate-400">
              {isEditing ? 'Update the details for this user.' : 'Create a new user account.'}
            </DialogDescription>
          </DialogHeader>
          <div className="grid gap-4 py-4">
            <div>
              <Label htmlFor="full_name">Full Name</Label>
              <Input id="full_name" name="full_name" value={currentUserData.full_name} onChange={handleInputChange} className="bg-slate-700 border-slate-600" />
            </div>
            <div>
              <Label htmlFor="email">Email</Label>
              <Input id="email" name="email" type="email" value={currentUserData.email} onChange={handleInputChange} disabled={isEditing} className="bg-slate-700 border-slate-600 disabled:opacity-70" />
            </div>
            {!isEditing && (
              <div>
                <Label htmlFor="password">Password</Label>
                <Input id="password" name="password" type="password" value={currentUserData.password} onChange={handleInputChange} className="bg-slate-700 border-slate-600" />
              </div>
            )}
            <div>
              <Label htmlFor="role">Role</Label>
              <Select value={currentUserData.role} onValueChange={handleRoleChange}>
                <SelectTrigger id="role" className="bg-slate-700 border-slate-600">
                  <SelectValue placeholder="Select role" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600 text-white">
                  <SelectItem value="admin">Admin</SelectItem>
                  <SelectItem value="rep">Rep</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={resetDialog} className="text-slate-300 border-slate-600 hover:bg-slate-700">Cancel</Button>
            <Button onClick={handleSubmitUser} disabled={loading} className="bg-green-600 hover:bg-green-700">
              {loading ? 'Saving...' : (isEditing ? 'Save Changes' : 'Create User')}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Card className="donation-card">
        <CardHeader>
          <CardTitle className="text-xl">Registered Users</CardTitle>
          <CardDescription>View and manage all users in the system.</CardDescription>
        </CardHeader>
        <CardContent>
          {loading && <p>Loading users...</p>}
          {!loading && users.length === 0 && <p>No users found.</p>}
          {!loading && users.length > 0 && (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700/30">
                    <TableHead className="text-gray-400">Full Name</TableHead>
                    <TableHead className="text-gray-400">Email</TableHead>
                    <TableHead className="text-gray-400">Role</TableHead>
                    <TableHead className="text-gray-400">Joined</TableHead>
                    <TableHead className="text-gray-400">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {users.map((user) => (
                    <TableRow key={user.id} className="border-slate-700 hover:bg-slate-700/30">
                      <TableCell className="text-white">{user.full_name || 'N/A'}</TableCell>
                      <TableCell className="text-slate-300">{user.email}</TableCell>
                      <TableCell>
                        <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${user.role === 'admin' ? 'bg-purple-600/30 text-purple-300' : 'bg-sky-600/30 text-sky-300'}`}>
                          <ShieldCheck className="mr-1 h-3 w-3" />{user.role.toUpperCase()}
                        </span>
                      </TableCell>
                      <TableCell className="text-slate-400">{new Date(user.created_at).toLocaleDateString()}</TableCell>
                      <TableCell className="space-x-2">
                        <Button variant="ghost" size="icon" onClick={() => handleEditUser(user)} className="text-blue-400 hover:text-blue-300">
                          <Edit3 className="h-4 w-4" />
                        </Button>
                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" disabled={user.id === currentUser.id} className="text-red-400 hover:text-red-300 disabled:opacity-50">
                              <Trash2 className="h-4 w-4" />
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent className="bg-slate-800 border-slate-700 text-white">
                            <AlertDialogHeader>
                              <AlertDialogTitle>Confirm Deletion</AlertDialogTitle>
                              <AlertDialogDescription className="text-slate-400">
                                Are you sure you want to delete user {user.email}? This action might be irreversible for their auth account.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel className="text-slate-300 border-slate-600 hover:bg-slate-700">Cancel</AlertDialogCancel>
                              <AlertDialogAction onClick={() => handleDeleteUser(user.id)} className="bg-red-600 hover:bg-red-700">Delete User</AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  );
};

export default UserManagementPage;
