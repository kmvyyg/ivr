import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Settings, User, Bell, Lock, CreditCard, Phone } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Switch } from '@/components/ui/switch';
import { toast } from '@/components/ui/use-toast';

const SettingsPage = () => {
  const [profileSettings, setProfileSettings] = useState({
    name: 'Admin User',
    email: 'admin@example.com',
  });
  const [notificationSettings, setNotificationSettings] = useState({
    newDonation: true,
    missedCall: true,
    voicemail: true,
    systemAlerts: true,
  });
  const [telephonyApiKey, setTelephonyApiKey] = useState('sk_test_xxxxxxxxxxxxxxxxxxxxxxxx'); // Example key

  const handleProfileChange = (e) => {
    setProfileSettings({ ...profileSettings, [e.target.name]: e.target.value });
  };

  const handleNotificationChange = (name) => {
    setNotificationSettings(prev => ({ ...prev, [name]: !prev[name] }));
  };

  const handleSaveSettings = (section) => {
    toast({
      title: `${section} Settings Saved`,
      description: `Your ${section.toLowerCase()} settings have been updated. (Simulated)`,
    });
  };

  return (
    <div className="space-y-8">
      <motion.h1 
        className="text-4xl font-bold text-gradient flex items-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <Settings className="mr-3 h-10 w-10" /> System Settings
      </motion.h1>
      <p className="text-lg text-gray-400">
        Configure your account, notification preferences, and integrations.
      </p>

      {/* Profile Settings */}
      <motion.div initial={{ opacity: 0, x: -20 }} animate={{ opacity: 1, x: 0 }}>
        <Card className="donation-card">
          <CardHeader>
            <CardTitle className="text-xl text-white flex items-center"><User className="mr-2 h-5 w-5 text-blue-400" /> Profile Settings</CardTitle>
            <CardDescription className="text-gray-400">Manage your personal information.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <Label htmlFor="name" className="text-gray-300">Full Name</Label>
              <Input id="name" name="name" value={profileSettings.name} onChange={handleProfileChange} className="bg-slate-700 border-slate-600 text-white" />
            </div>
            <div>
              <Label htmlFor="email" className="text-gray-300">Email Address</Label>
              <Input id="email" name="email" type="email" value={profileSettings.email} onChange={handleProfileChange} className="bg-slate-700 border-slate-600 text-white" />
            </div>
            <Button onClick={() => handleSaveSettings('Profile')} className="bg-blue-600 hover:bg-blue-700">Save Profile</Button>
          </CardContent>
        </Card>
      </motion.div>

      {/* Notification Settings */}
      <motion.div initial={{ opacity: 0, x: 20 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.1 }}>
        <Card className="donation-card">
          <CardHeader>
            <CardTitle className="text-xl text-white flex items-center"><Bell className="mr-2 h-5 w-5 text-yellow-400" /> Notification Settings</CardTitle>
            <CardDescription className="text-gray-400">Choose how you receive alerts.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {Object.entries(notificationSettings).map(([key, value]) => (
              <div key={key} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                <Label htmlFor={key} className="text-gray-300 capitalize">
                  {key.replace(/([A-Z])/g, ' $1').trim()} Alerts
                </Label>
                <Switch
                  id={key}
                  checked={value}
                  onCheckedChange={() => handleNotificationChange(key)}
                  className="data-[state=checked]:bg-yellow-500"
                />
              </div>
            ))}
            <Button onClick={() => handleSaveSettings('Notification')} className="bg-yellow-600 hover:bg-yellow-700">Save Notifications</Button>
          </CardContent>
        </Card>
      </motion.div>
      
      {/* Integrations Settings */}
      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <Card className="donation-card">
          <CardHeader>
            <CardTitle className="text-xl text-white flex items-center"><Lock className="mr-2 h-5 w-5 text-green-400" /> Integrations</CardTitle>
            <CardDescription className="text-gray-400">Manage API keys and third-party connections.</CardDescription>
          </CardHeader>
          <CardContent className="space-y-6">
            {/* Telephony API */}
            <div className="p-4 border border-slate-700 rounded-lg">
              <h3 className="text-lg font-semibold text-white flex items-center mb-2">
                <Phone className="mr-2 h-5 w-5 text-purple-400" /> Telephony API (e.g., Twilio)
              </h3>
              <div>
                <Label htmlFor="telephonyApiKey" className="text-gray-300">API Key</Label>
                <Input 
                  id="telephonyApiKey" 
                  type="password" 
                  value={telephonyApiKey} 
                  onChange={(e) => setTelephonyApiKey(e.target.value)} 
                  className="bg-slate-700 border-slate-600 text-white" 
                  placeholder="Enter your Telephony API Key"
                />
              </div>
              <Button onClick={() => handleSaveSettings('Telephony API')} className="mt-3 bg-purple-600 hover:bg-purple-700">Save Telephony Key</Button>
            </div>

            {/* Payment Gateway */}
            <div className="p-4 border border-slate-700 rounded-lg">
              <h3 className="text-lg font-semibold text-white flex items-center mb-2">
                <CreditCard className="mr-2 h-5 w-5 text-green-400" /> Payment Gateway (e.g., Stripe)
              </h3>
              <p className="text-sm text-gray-400 mb-2">
                Connect your Stripe account to process donations securely. You'll need your Publishable Key and Price ID.
              </p>
              <Button 
                onClick={() => {
                  toast({
                    title: "Stripe Integration",
                    description: "You will be guided through Stripe setup process. This is a placeholder.",
                  });
                }} 
                className="bg-green-600 hover:bg-green-700"
              >
                Connect Stripe Account
              </Button>
               <p className="text-xs text-gray-500 mt-2">Note: Supabase integration is required for storing transaction data securely.</p>
            </div>
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default SettingsPage;