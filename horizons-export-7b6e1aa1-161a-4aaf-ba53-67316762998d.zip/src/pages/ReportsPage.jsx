
import React, { useState, useMemo, useEffect } from 'react';
import { motion } from 'framer-motion';
import { FileText, Calendar, Filter, Download, PlayCircle, DollarSign, PhoneForwarded, ListTree, AlertTriangle, CheckSquare } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';

const ReportsPage = () => {
  const [callLogs, setCallLogs] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filters, setFilters] = useState({
    dateFrom: '',
    dateTo: '',
    eventTypePrefix: 'all', // 'all', 'general-ivr', 'sim-general-ivr', 'donation', etc.
    callerId: '',
  });

  useEffect(() => {
    fetchCallLogs();
  }, []);

  const fetchCallLogs = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase
        .from('call_events')
        .select('*')
        .order('created_at', { ascending: false })
        .limit(100); // Fetch latest 100, add pagination later if needed

      if (error) throw error;
      
      const formattedLogs = data.map(log => ({
        id: log.id,
        timestamp: new Date(log.created_at).toLocaleString(),
        callerId: log.caller_id || 'N/A',
        eventType: log.event_type || 'N/A',
        callSid: log.event_data?.callSid || 'N/A',
        details: log.event_data || {},
        notes: log.notes || '',
      }));
      setCallLogs(formattedLogs);
    } catch (error) {
      toast({
        title: "Error Fetching Call Logs",
        description: error.message,
        variant: "destructive",
      });
      setCallLogs([]);
    } finally {
      setLoading(false);
    }
  };


  const handleFilterChange = (filterName, value) => {
    setFilters(prev => ({ ...prev, [filterName]: value }));
  };

  const filteredLogs = useMemo(() => {
    return callLogs.filter(log => {
      const logDate = new Date(log.timestamp);
      const dateFrom = filters.dateFrom ? new Date(filters.dateFrom) : null;
      const dateTo = filters.dateTo ? new Date(filters.dateTo) : null;

      if (dateFrom && logDate < dateFrom) return false;
      if (dateTo && logDate > dateTo) return false;
      if (filters.eventTypePrefix !== 'all' && !log.eventType.startsWith(filters.eventTypePrefix)) return false;
      if (filters.callerId && !log.callerId.includes(filters.callerId)) return false;
      
      return true;
    });
  }, [callLogs, filters]);
  
  const downloadReport = () => {
    if (filteredLogs.length === 0) {
      toast({ title: "No Data", description: "No logs to download with current filters.", variant: "destructive" });
      return;
    }
    const csvHeader = "Timestamp,Caller ID,Event Type,Call SID,Details,Notes\n";
    const csvRows = filteredLogs.map(log => 
      [
        `"${log.timestamp}"`,
        `"${log.callerId}"`,
        `"${log.eventType}"`,
        `"${log.callSid}"`,
        `"${JSON.stringify(log.details).replace(/"/g, '""')}"`,
        `"${log.notes.replace(/"/g, '""')}"`
      ].join(',')
    ).join('\n');
    
    const csvContent = csvHeader + csvRows;
    const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
    const link = document.createElement("a");
    if (link.download !== undefined) {
      const url = URL.createObjectURL(blob);
      link.setAttribute("href", url);
      link.setAttribute("download", `call_report_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      toast({ title: "Report Downloaded", description: "CSV report generated." });
    } else {
       toast({ title: "Download Failed", description: "Browser does not support direct download.", variant: "destructive" });
    }
  }

  const getEventTypeDisplay = (eventType) => {
    if (eventType.startsWith('general-ivr-')) return { text: eventType.replace('general-ivr-', 'IVR: '), icon: ListTree, color: 'text-sky-300', bg: 'bg-sky-600/20' };
    if (eventType.startsWith('sim-general-ivr-')) return { text: eventType.replace('sim-general-ivr-', 'Sim IVR: '), icon: ListTree, color: 'text-teal-300', bg: 'bg-teal-600/20' };
    if (eventType.includes('donation')) return { text: eventType, icon: DollarSign, color: 'text-green-300', bg: 'bg-green-600/20' };
    if (eventType.includes('error') || eventType.includes('failed')) return { text: eventType, icon: AlertTriangle, color: 'text-red-300', bg: 'bg-red-600/20' };
    return { text: eventType, icon: CheckSquare, color: 'text-gray-300', bg: 'bg-slate-600/20' };
  }

  return (
    <div className="space-y-8">
      <motion.h1 
        className="text-4xl font-bold text-gradient flex items-center"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        <FileText className="mr-3 h-10 w-10" /> Call Event Logs
      </motion.h1>
      <p className="text-lg text-gray-400">
        View detailed logs for all call events, including IVR interactions and simulated calls from Supabase.
      </p>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.1 }}>
        <Card className="donation-card">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-xl text-white flex items-center"><Filter className="mr-2 h-5 w-5" /> Filter Logs</CardTitle>
            <Button onClick={fetchCallLogs} disabled={loading} className="bg-indigo-600 hover:bg-indigo-700">
              {loading ? 'Refreshing...' : 'Refresh Logs'}
            </Button>
          </CardHeader>
          <CardContent className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
            <div>
              <Label htmlFor="dateFrom" className="text-gray-300">Date From</Label>
              <Input type="date" id="dateFrom" value={filters.dateFrom} onChange={e => handleFilterChange('dateFrom', e.target.value)} className="bg-slate-700 border-slate-600 text-white" />
            </div>
            <div>
              <Label htmlFor="dateTo" className="text-gray-300">Date To</Label>
              <Input type="date" id="dateTo" value={filters.dateTo} onChange={e => handleFilterChange('dateTo', e.target.value)} className="bg-slate-700 border-slate-600 text-white" />
            </div>
            <div>
              <Label htmlFor="eventTypePrefix" className="text-gray-300">Event Type Prefix</Label>
              <Select value={filters.eventTypePrefix} onValueChange={value => handleFilterChange('eventTypePrefix', value)}>
                <SelectTrigger id="eventTypePrefix" className="bg-slate-700 border-slate-600 text-white">
                  <SelectValue placeholder="Select prefix" />
                </SelectTrigger>
                <SelectContent className="bg-slate-700 border-slate-600 text-white">
                  <SelectItem value="all" className="hover:bg-slate-600">All Events</SelectItem>
                  <SelectItem value="general-ivr-" className="hover:bg-slate-600">General IVR (Live)</SelectItem>
                  <SelectItem value="sim-general-ivr-" className="hover:bg-slate-600">General IVR (Simulated)</SelectItem>
                  <SelectItem value="donation" className="hover:bg-slate-600">Donation Related</SelectItem>
                  <SelectItem value="sim-call" className="hover:bg-slate-600">Donation Sim Call</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <Label htmlFor="callerId" className="text-gray-300">Caller ID / Call SID</Label>
              <Input type="text" id="callerId" placeholder="Enter phone or SID" value={filters.callerId} onChange={e => handleFilterChange('callerId', e.target.value)} className="bg-slate-700 border-slate-600 placeholder-slate-400 text-white" />
            </div>
          </CardContent>
        </Card>
      </motion.div>

      <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.2 }}>
        <Card className="donation-card">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-xl text-white">Event Log Details</CardTitle>
            <Button onClick={downloadReport} className="bg-blue-600 hover:bg-blue-700">
              <Download className="mr-2 h-4 w-4" /> Download Filtered CSV
            </Button>
          </CardHeader>
          <CardContent>
            {loading ? (
              <p className="text-gray-400 text-center py-8">Loading call logs...</p>
            ) : filteredLogs.length === 0 ? (
              <p className="text-gray-400 text-center py-8">No call logs match your current filters.</p>
            ) : (
            <div className="overflow-x-auto">
              <Table>
                <TableHeader>
                  <TableRow className="border-slate-700 hover:bg-slate-700/30">
                    <TableHead className="text-gray-400">Timestamp</TableHead>
                    <TableHead className="text-gray-400">Caller/Sim ID</TableHead>
                    <TableHead className="text-gray-400">Event Type</TableHead>
                    <TableHead className="text-gray-400">Call SID</TableHead>
                    <TableHead className="text-gray-400">Details</TableHead>
                    <TableHead className="text-gray-400">Notes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredLogs.map(log => {
                    const eventDisplay = getEventTypeDisplay(log.eventType);
                    return (
                      <TableRow key={log.id} className="border-slate-700 hover:bg-slate-700/30">
                        <TableCell className="text-gray-300 whitespace-nowrap">{log.timestamp}</TableCell>
                        <TableCell className="text-white whitespace-nowrap">{log.callerId}</TableCell>
                        <TableCell>
                          <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${eventDisplay.bg} ${eventDisplay.color}`}>
                            <eventDisplay.icon className="mr-1 h-3 w-3" />
                            {eventDisplay.text}
                          </span>
                        </TableCell>
                        <TableCell className="text-gray-300 whitespace-nowrap">{log.callSid}</TableCell>
                        <TableCell className="text-gray-400 text-xs max-w-xs overflow-hidden truncate hover:whitespace-normal hover:overflow-visible">
                          {Object.entries(log.details).map(([key, value]) => `${key}: ${typeof value === 'object' ? JSON.stringify(value) : value}`).join('; ') || 'N/A'}
                        </TableCell>
                        <TableCell className="text-gray-400 text-xs">{log.notes}</TableCell>
                      </TableRow>
                    );
                  })}
                </TableBody>
              </Table>
            </div>
            )}
          </CardContent>
        </Card>
      </motion.div>
    </div>
  );
};

export default ReportsPage;
