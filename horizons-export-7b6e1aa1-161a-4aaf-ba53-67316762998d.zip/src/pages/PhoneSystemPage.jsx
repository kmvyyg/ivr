import React, { useState, useEffect, useRef } from 'react';
import { motion } from 'framer-motion';
import { Phone, Headphones, CheckCircle, AlertCircle, ChevronRight, XCircle, DollarSign, MapPin, Loader2, ExternalLink, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { toast } from '@/components/ui/use-toast';
import { supabase } from '@/lib/supabaseClient';

const CALL_STEPS = {
  WELCOME: 'WELCOME',
  GET_AMOUNT: 'GET_AMOUNT',
  CONFIRM_AMOUNT: 'CONFIRM_AMOUNT',
  GET_ZIP: 'GET_ZIP',
  CONFIRM_ZIP: 'CONFIRM_ZIP',
  PROCESSING: 'PROCESSING',
  THANK_YOU: 'THANK_YOU',
  FAILED: 'FAILED',
  REPROMPT_AMOUNT: 'REPROMPT_AMOUNT',
  REPROMPT_ZIP: 'REPROMPT_ZIP',
};

const SCRIPT = {
  [CALL_STEPS.WELCOME]: {
    text: "Welcome to Hope Foundation. Thank you for calling our donation line. We will now ask for your donation amount.",
    audio: null, 
  },
  [CALL_STEPS.GET_AMOUNT]: {
    text: "Please enter the 4-digit amount you'd like to donate in dollars, then press pound.",
    audio: 'https://raw.githubusercontent.com/kmvyyg/donation/main/MM_2.mp3',
    inputType: 'amount',
    maxLength: 4,
  },
  [CALL_STEPS.REPROMPT_AMOUNT]: {
    text: "No amount was entered. Please enter the 4-digit amount you'd like to donate, then press pound.",
    audio: 'https://raw.githubusercontent.com/kmvyyg/donation/main/MM_2.mp3',
    inputType: 'amount',
    maxLength: 4,
  },
  [CALL_STEPS.CONFIRM_AMOUNT]: {
    text: (amount) => `You entered ${amount} dollars. Is this correct? Press 1 for yes, 2 for no.`,
    audio: null, 
    inputType: 'confirmation',
    maxLength: 1,
  },
  [CALL_STEPS.GET_ZIP]: {
    text: "Thank you. Please enter your 5-digit ZIP code, then press pound.",
    audio: 'https://raw.githubusercontent.com/kmvyyg/donation/main/MM_8.mp3',
    inputType: 'zip',
    maxLength: 5,
  },
  [CALL_STEPS.REPROMPT_ZIP]: {
    text: "No ZIP code was entered. Please enter your 5-digit ZIP code, then press pound.",
    audio: 'https://raw.githubusercontent.com/kmvyyg/donation/main/MM_8.mp3',
    inputType: 'zip',
    maxLength: 5,
  },
  [CALL_STEPS.CONFIRM_ZIP]: {
    text: (zip) => `You entered ${zip}. Is this correct? Press 1 for yes, 2 for no.`,
    audio: null, 
    inputType: 'confirmation',
    maxLength: 1,
  },
  [CALL_STEPS.PROCESSING]: {
    text: "Thank you! We're processing your donation...",
    audio: null,
  },
  [CALL_STEPS.THANK_YOU]: {
    text: "Your donation has been successfully processed. Thank you for your generosity!",
    audio: null, 
  },
  [CALL_STEPS.FAILED]: {
    text: "We couldn't process your donation at this time. Please try again later or visit our website. Thank you for calling.",
    audio: null,
  }
};

const logCallEventToSupabase = async (callerId, eventType, eventData, notes = '') => {
  try {
    const { error } = await supabase
      .from('call_events')
      .insert([{ caller_id: callerId, event_type: eventType, event_data: eventData, notes: notes }]);
    if (error) throw error;
  } catch (error) {
    console.error('Error logging call event to Supabase:', error.message);
    toast({
      title: "Supabase Logging Error",
      description: `Could not log event: ${eventType}. ${error.message}`,
      variant: "destructive",
    });
  }
};

const PhoneSystemPage = () => {
  const [currentStep, setCurrentStep] = useState(CALL_STEPS.WELCOME);
  const [isCallActive, setIsCallActive] = useState(false);
  const [inputValue, setInputValue] = useState('');
  const [donationAmount, setDonationAmount] = useState('');
  const [zipCode, setZipCode] = useState('');
  const [callId, setCallId] = useState(null);
  const audioRef = useRef(null);
  const [edgeFunctionUrl, setEdgeFunctionUrl] = useState('');

  useEffect(() => {
    // Construct the Edge Function URL based on your Supabase project
    // Replace 'vjfppgynkgysliadpfvt' with your actual Supabase project reference if different
    const projectRef = 'vjfppgynkgysliadpfvt'; 
    setEdgeFunctionUrl(`https://${projectRef}.supabase.co/functions/v1/twilio-voice-ivr`);
  }, []);

  const currentScript = SCRIPT[currentStep];
  const promptText = typeof currentScript.text === 'function' 
    ? currentScript.text(currentStep === CALL_STEPS.CONFIRM_AMOUNT ? donationAmount : zipCode) 
    : currentScript.text;

  useEffect(() => {
    if (currentScript?.audio && isCallActive && audioRef.current) {
      audioRef.current.src = currentScript.audio;
      audioRef.current.play().catch(e => console.warn("Audio playback prevented:", e));
    }
  }, [currentStep, currentScript, isCallActive]);

  const startCall = () => {
    const newCallId = `sim-${Date.now()}`;
    setCallId(newCallId);
    setIsCallActive(true);
    setCurrentStep(CALL_STEPS.WELCOME);
    setDonationAmount('');
    setZipCode('');
    setInputValue('');
    logCallEventToSupabase(newCallId, 'sim-call-started', { timestamp: new Date().toISOString() }, 'Frontend Simulation');
    
    setTimeout(() => {
      setCurrentStep(CALL_STEPS.GET_AMOUNT);
    }, 3000); 
  };

  const endCall = (status) => {
    setIsCallActive(false);
    logCallEventToSupabase(callId, 'sim-call-ended', { status, timestamp: new Date().toISOString() }, 'Frontend Simulation');
    if (audioRef.current) {
      audioRef.current.pause();
      audioRef.current.currentTime = 0;
    }
  };

  const handleInputChange = (e) => {
    const val = e.target.value;
    if (currentScript.maxLength && val.length <= currentScript.maxLength) {
      setInputValue(val);
    } else if (!currentScript.maxLength) {
      setInputValue(val);
    }
  };

  const handleSubmitInput = async () => {
    if (!inputValue.trim() && (currentStep === CALL_STEPS.GET_AMOUNT || currentStep === CALL_STEPS.GET_ZIP)) {
      logCallEventToSupabase(callId, 'sim-dtmf-input-empty', { step: currentStep }, 'Frontend Simulation');
      setCurrentStep(currentStep === CALL_STEPS.GET_AMOUNT ? CALL_STEPS.REPROMPT_AMOUNT : CALL_STEPS.REPROMPT_ZIP);
      setInputValue('');
      return;
    }

    logCallEventToSupabase(callId, 'sim-dtmf-input', { step: currentStep, value: inputValue }, 'Frontend Simulation');

    switch (currentStep) {
      case CALL_STEPS.GET_AMOUNT:
      case CALL_STEPS.REPROMPT_AMOUNT:
        setDonationAmount(inputValue);
        setCurrentStep(CALL_STEPS.CONFIRM_AMOUNT);
        break;
      case CALL_STEPS.CONFIRM_AMOUNT:
        if (inputValue === '1') { // Yes
          logCallEventToSupabase(callId, 'sim-donation-amount-confirmed', { amount: donationAmount }, 'Frontend Simulation');
          setCurrentStep(CALL_STEPS.GET_ZIP);
        } else { // No or invalid
          logCallEventToSupabase(callId, 'sim-donation-amount-rejected', { amount: donationAmount }, 'Frontend Simulation');
          setDonationAmount('');
          setCurrentStep(CALL_STEPS.GET_AMOUNT);
        }
        break;
      case CALL_STEPS.GET_ZIP:
      case CALL_STEPS.REPROMPT_ZIP:
        setZipCode(inputValue);
        setCurrentStep(CALL_STEPS.CONFIRM_ZIP);
        break;
      case CALL_STEPS.CONFIRM_ZIP:
        if (inputValue === '1') { // Yes
          logCallEventToSupabase(callId, 'sim-zip-code-confirmed', { zip: zipCode }, 'Frontend Simulation');
          setCurrentStep(CALL_STEPS.PROCESSING);
          setTimeout(async () => {
            const success = Math.random() > 0.2; 
            if (success) {
              await logCallEventToSupabase(callId, 'sim-donation-processed', { amount: donationAmount, zip: zipCode }, 'Frontend Simulation');
              setCurrentStep(CALL_STEPS.THANK_YOU);
              toast({
                title: "Simulated Donation Success!",
                description: `${donationAmount} donation from ZIP ${zipCode} processed.`,
                action: <CheckCircle className="text-green-500" />,
              });
              setTimeout(() => endCall('success'), 5000);
            } else {
              await logCallEventToSupabase(callId, 'sim-donation-failed', { amount: donationAmount, zip: zipCode, reason: "Simulated payment failure" }, 'Frontend Simulation');
              setCurrentStep(CALL_STEPS.FAILED);
              toast({
                title: "Simulated Donation Failed",
                description: "The payment could not be processed.",
                variant: "destructive",
                action: <XCircle className="text-red-500" />,
              });
              setTimeout(() => endCall('failed'), 5000);
            }
          }, 3000);
        } else { // No or invalid
          logCallEventToSupabase(callId, 'sim-zip-code-rejected', { zip: zipCode }, 'Frontend Simulation');
          setZipCode('');
          setCurrentStep(CALL_STEPS.GET_ZIP);
        }
        break;
      default:
        break;
    }
    setInputValue('');
  };

  const renderCallStepUI = () => {
    if (!isCallActive) {
      return (
        <Button
          onClick={startCall}
          className="w-full bg-green-600 hover:bg-green-700 text-white py-3 text-lg"
          size="lg"
        >
          <Phone className="w-5 h-5 mr-2" />
          Start Demo Call Simulation
        </Button>
      );
    }

    return (
      <div className="space-y-4 p-4 bg-slate-700/50 rounded-lg">
        <div className="flex items-center text-lg font-semibold text-green-400">
          <Headphones className="w-6 h-6 mr-2 animate-pulse" />
          Call Simulation In Progress... (ID: {callId})
        </div>
        <Card className="bg-slate-800 border-slate-700">
          <CardHeader>
            <CardTitle className="text-fuchsia-400">Operator Script (Simulation):</CardTitle>
          </CardHeader>
          <CardContent>
            <p className="text-white text-lg min-h-[60px]">{promptText}</p>
            {currentScript.audio && (
              <audio ref={audioRef} className="w-full mt-2 hidden" controls />
            )}
          </CardContent>
        </Card>

        {currentScript.inputType && currentStep !== CALL_STEPS.PROCESSING && currentStep !== CALL_STEPS.THANK_YOU && currentStep !== CALL_STEPS.FAILED && (
          <div className="space-y-2">
            <Label htmlFor="dtmfInput" className="text-gray-300">
              {currentScript.inputType === 'amount' && <DollarSign className="inline mr-1 h-4 w-4" />}
              {currentScript.inputType === 'zip' && <MapPin className="inline mr-1 h-4 w-4" />}
              {currentScript.inputType === 'confirmation' && <CheckCircle className="inline mr-1 h-4 w-4" />}
              Enter Digits (Simulated DTMF):
            </Label>
            <div className="flex space-x-2">
              <Input
                id="dtmfInput"
                type="text"
                pattern="\d*"
                value={inputValue}
                onChange={handleInputChange}
                maxLength={currentScript.maxLength}
                className="bg-slate-600 border-slate-500 text-white placeholder-slate-400 text-lg tracking-widest"
                placeholder={currentScript.maxLength ? `Max ${currentScript.maxLength} digits` : "Digits"}
              />
              <Button onClick={handleSubmitInput} className="bg-fuchsia-600 hover:bg-fuchsia-700 text-white">
                Send <ChevronRight className="w-4 h-4 ml-1" />
              </Button>
            </div>
          </div>
        )}

        {currentStep === CALL_STEPS.PROCESSING && (
          <div className="flex items-center justify-center text-white py-4">
            <Loader2 className="w-8 h-8 mr-3 animate-spin text-fuchsia-400" />
            Processing your request...
          </div>
        )}

        {(currentStep === CALL_STEPS.THANK_YOU || currentStep === CALL_STEPS.FAILED) && (
          <Button onClick={() => endCall('manual_hangup')} variant="destructive" className="w-full mt-4">
            End Simulation
          </Button>
        )}
      </div>
    );
  };


  return (
    <div className="space-y-8">
      <motion.h1 
        className="text-4xl font-bold text-gradient"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        Phone Donation System
      </motion.h1>
      
      <Card className="donation-card bg-indigo-600/20 border-indigo-500">
        <CardHeader>
          <CardTitle className="text-xl text-indigo-300 flex items-center"><Info className="w-5 h-5 mr-2"/>Twilio Integration via Supabase Edge Function</CardTitle>
        </CardHeader>
        <CardContent className="text-indigo-200 space-y-2">
          <p>
            To connect this IVR logic to a real Twilio phone number, a Supabase Edge Function has been created.
            Configure your Twilio phone number's voice webhook (when a call comes in) to point to the following URL using HTTP POST:
          </p>
          <div className="p-2 bg-slate-900/50 rounded font-mono text-sm break-all flex items-center">
            {edgeFunctionUrl ? edgeFunctionUrl : "Loading URL..."}
            {edgeFunctionUrl && 
              <Button variant="ghost" size="sm" className="ml-2 text-indigo-300 hover:text-indigo-200" onClick={() => navigator.clipboard.writeText(edgeFunctionUrl).then(() => toast({title: "URL Copied!"}))}>
                Copy URL
              </Button>
            }
          </div>
          <p className="text-xs">
            This Edge Function will handle incoming calls, play prompts, gather DTMF input, and log events to the `call_events` table in Supabase.
            The simulation below helps visualize this flow.
          </p>
          <a href="https://www.twilio.com/docs/voice/tutorials/how-to-respond-to-incoming-phone-calls" target="_blank" rel="noopener noreferrer" className="inline-flex items-center text-indigo-300 hover:text-indigo-100 underline">
            Twilio Webhook Guide <ExternalLink className="w-4 h-4 ml-1" />
          </a>
        </CardContent>
      </Card>


      <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 items-start">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <Card className="donation-card min-h-[300px]">
            <CardHeader>
              <CardTitle className="text-xl text-white">Simulate Phone Call (Frontend)</CardTitle>
              <CardDescription className="text-gray-400">Test the multi-step DTMF donation flow locally.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6">
              {renderCallStepUI()}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
        >
          <Card className="donation-card">
            <CardHeader>
              <CardTitle className="text-xl text-white">Call Flow Overview (Simulated & Edge Function)</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              {[
                { name: 'Welcome Message', step: CALL_STEPS.WELCOME, icon: Phone },
                { name: 'Get Donation Amount', step: CALL_STEPS.GET_AMOUNT, icon: DollarSign },
                { name: 'Get ZIP Code', step: CALL_STEPS.GET_ZIP, icon: MapPin },
                { name: 'Process & Thank You / Fail', step: CALL_STEPS.THANK_YOU, icon: CheckCircle },
              ].map((item, index) => (
                <div key={index} className={`flex items-center space-x-3 p-2 rounded-md ${isCallActive && (currentStep === item.step || (item.step === CALL_STEPS.THANK_YOU && (currentStep === CALL_STEPS.FAILED || currentStep === CALL_STEPS.THANK_YOU))) ? 'bg-fuchsia-600/30 ring-2 ring-fuchsia-500' : 'bg-slate-700/50'}`}>
                  <item.icon className={`w-5 h-5 ${isCallActive && currentStep === item.step ? 'text-fuchsia-400 animate-pulse' : 'text-gray-400'}`} />
                  <span className={`${isCallActive && currentStep === item.step ? 'text-fuchsia-300 font-semibold' : 'text-gray-300'}`}>{item.name}</span>
                </div>
              ))}
              <div className="mt-4 p-3 bg-blue-600/20 rounded-lg flex items-start space-x-3">
                <AlertCircle className="w-5 h-5 text-blue-400 mt-1 flex-shrink-0" />
                <p className="text-sm text-blue-300">
                  The Edge Function implements a simplified version of this flow. The simulation here includes more detailed confirmation steps.
                </p>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default PhoneSystemPage;