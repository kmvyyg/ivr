
import React, { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { Users, PhoneCall, Clock, CheckCircle, AlertTriangle, Database, Activity, BarChart2, ListChecks } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { supabase } from '@/lib/supabaseClient'; 
import { toast } from '@/components/ui/use-toast';

const DashboardPage = ({user: currentUser}) => {
  const [systemStats, setSystemStats] = useState({
    totalUsers: 0,
    activeCalls: 0, 
    avgCallDuration: 'N/A', 
    totalCallsToday: 0,
  });
  const [recentCallLogs, setRecentCallLogs] = useState([]);
  const [supabaseStatus, setSupabaseStatus] = useState({ connected: false, message: 'Connecting...' });
  const [loadingStats, setLoadingStats] = useState(true);

  useEffect(() => {
    const checkSupabaseConnection = async () => {
      try {
        const { data, error } = await supabase.from('users').select('id', { count: 'exact', head: true }).limit(1); // Simple query
        if (error) throw error;
        setSupabaseStatus({ connected: true, message: 'Supabase Connected!' });
        toast({
          title: "Supabase Connected!",
          description: "Successfully connected to your Supabase project.",
          duration: 3000,
          className: "bg-green-600 border-green-700 text-white",
          icon: <CheckCircle className="h-5 w-5" />,
        });
      } catch (error) {
        console.error("Supabase connection error:", error);
        setSupabaseStatus({ connected: false, message: 'Supabase Connection Failed' });
        toast({
          title: "Supabase Connection Failed",
          description: error.message || "Could not connect to Supabase.",
          variant: "destructive",
          icon: <AlertTriangle className="h-5 w-5" />,
        });
      }
    };

    const fetchDashboardData = async () => {
      setLoadingStats(true);
      try {
        // Fetch total users
        const { count: usersCount, error: usersError } = await supabase
          .from('users')
          .select('id', { count: 'exact', head: true });
        if (usersError) throw usersError;

        // Fetch call stats (example: total calls today, active calls (simulated))
        // For real active calls, you'd need a more complex state management or backend service
        const todayStart = new Date();
        todayStart.setHours(0,0,0,0);
        
        const { count: callsTodayCount, error: callsTodayError } = await supabase
            .from('call_logs')
            .select('id', { count: 'exact', head: true })
            .gte('start_time', todayStart.toISOString());
        if(callsTodayError) throw callsTodayError;
        
        // Avg Call Duration - more complex SQL or iterate over recent calls
        const { data: completedCalls, error: avgDurError } = await supabase
            .from('call_logs')
            .select('duration_seconds')
            .not('duration_seconds', 'is', null)
            .limit(50); // Base on recent 50 calls
        if(avgDurError) throw avgDurError;
        
        let avgDurationSeconds = 0;
        if (completedCalls && completedCalls.length > 0) {
            const totalDuration = completedCalls.reduce((acc, call) => acc + (call.duration_seconds || 0), 0);
            avgDurationSeconds = Math.floor(totalDuration / completedCalls.length);
        }
        const avgDurationFormatted = `${Math.floor(avgDurationSeconds / 60)}m ${avgDurationSeconds % 60}s`;


        setSystemStats({
          totalUsers: usersCount || 0,
          activeCalls: Math.floor(Math.random() * 5), // Simulated
          avgCallDuration: avgDurationFormatted,
          totalCallsToday: callsTodayCount || 0,
        });

        // Fetch recent call logs
        const { data: logsData, error: logsError } = await supabase
          .from('call_logs')
          .select('id, direction, status, external_party_number, duration_seconds, start_time, users(full_name)')
          .order('start_time', { ascending: false })
          .limit(5);
        if (logsError) throw logsError;
        setRecentCallLogs(logsData || []);

      } catch (error) {
        toast({ title: "Error fetching dashboard data", description: error.message, variant: "destructive" });
      } finally {
        setLoadingStats(false);
      }
    };

    checkSupabaseConnection();
    fetchDashboardData();
    
    const intervalId = setInterval(fetchDashboardData, 60000); // Refresh every minute
    return () => clearInterval(intervalId);

  }, []);

  const statCards = [
    { label: 'Total Users', value: systemStats.totalUsers, icon: Users, color: 'text-sky-400', unit: '' },
    { label: 'Active Calls (Sim.)', value: systemStats.activeCalls, icon: PhoneCall, color: 'text-fuchsia-400', unit: '' },
    { label: 'Avg Call Duration', value: systemStats.avgCallDuration, icon: Clock, color: 'text-amber-400', unit: '' },
    { label: 'Calls Today', value: systemStats.totalCallsToday, icon: BarChart2, color: 'text-emerald-400', unit: '' },
  ];
  
  const formatDuration = (seconds) => {
    if (seconds === null || seconds === undefined) return 'N/A';
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}m ${s}s`;
  };

  return (
    <div className="space-y-10">
      <motion.h1 
        className="text-5xl font-bold text-gradient tracking-tight"
        initial={{ opacity: 0, y: -20 }}
        animate={{ opacity: 1, y: 0 }}
      >
        Welcome, {currentUser?.full_name || currentUser?.email}!
      </motion.h1>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        {statCards.map((stat, index) => (
          <motion.div
            key={stat.label}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: index * 0.1 + 0.1 }}
          >
            <Card className="donation-card shadow-lg hover:shadow-purple-500/30 transition-shadow">
              <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
                <CardTitle className="text-md font-medium text-slate-300">{stat.label}</CardTitle>
                <stat.icon className={`h-6 w-6 ${stat.color}`} />
              </CardHeader>
              <CardContent>
                {loadingStats ? <div className="h-10 bg-slate-700 rounded animate-pulse w-3/4"></div> :
                  <div className="text-4xl font-extrabold text-white">
                    {stat.value}
                    <span className="text-2xl font-medium text-slate-400 ml-1">{stat.unit}</span>
                  </div>
                }
                <p className="text-xs text-slate-400 mt-1">{stat.description || `Current system ${stat.label.toLowerCase()}`}</p>
              </CardContent>
            </Card>
          </motion.div>
        ))}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
        <motion.div 
          className="lg:col-span-2"
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="donation-card shadow-lg h-full">
            <CardHeader>
              <CardTitle className="text-2xl text-white flex items-center"><ListChecks className="mr-2 text-indigo-400"/>Recent Call Logs</CardTitle>
              <CardDescription className="text-slate-400">Latest call activity in the system.</CardDescription>
            </CardHeader>
            <CardContent>
              {loadingStats ? <div className="h-40 bg-slate-700 rounded animate-pulse"></div> : 
                recentCallLogs.length === 0 ? <p className="text-slate-400 text-center py-10">No recent calls found.</p> : (
                <div className="overflow-x-auto">
                <Table>
                  <TableHeader>
                    <TableRow className="border-slate-700">
                      <TableHead className="text-slate-400">External Party</TableHead>
                      <TableHead className="text-slate-400">Agent</TableHead>
                      <TableHead className="text-slate-400">Direction</TableHead>
                      <TableHead className="text-slate-400">Status</TableHead>
                      <TableHead className="text-slate-400">Duration</TableHead>
                      <TableHead className="text-slate-400">Time</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {recentCallLogs.map((log) => (
                      <TableRow key={log.id} className="border-slate-700 hover:bg-slate-700/40">
                        <TableCell className="font-medium text-white">{log.external_party_number}</TableCell>
                        <TableCell className="text-slate-300">{log.users?.full_name || 'System'}</TableCell>
                        <TableCell className="text-slate-300 capitalize">{log.direction}</TableCell>
                        <TableCell>
                          <span className={`px-2.5 py-1 rounded-full text-xs font-semibold ${
                            log.status === 'completed' ? 'bg-green-500/20 text-green-400' :
                            log.status === 'answered' ? 'bg-blue-500/20 text-blue-400' :
                            log.status === 'failed' || log.status === 'busy' || log.status === 'no_answer' ? 'bg-red-500/20 text-red-400' :
                            'bg-slate-500/20 text-slate-300'
                          }`}>
                            {log.status.replace('_', ' ').toUpperCase()}
                          </span>
                        </TableCell>
                        <TableCell className="text-slate-300">{formatDuration(log.duration_seconds)}</TableCell>
                        <TableCell className="text-slate-400 text-xs">{new Date(log.start_time).toLocaleTimeString()}</TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="donation-card shadow-lg h-full">
            <CardHeader>
              <CardTitle className="text-2xl text-white flex items-center"><Activity className="mr-2 text-teal-400"/>System Health</CardTitle>
               <CardDescription className="text-slate-400">Overview of critical system components.</CardDescription>
            </CardHeader>
            <CardContent className="space-y-6 pt-2">
              <div>
                <div className="flex justify-between mb-1.5">
                  <span className="text-md font-medium text-slate-200">Telephony API</span>
                  <span className="text-md font-medium text-green-400">Operational</span>
                </div>
                <Progress value={100} className="h-2.5 [&>div]:bg-green-500" />
              </div>
              <div>
                <div className="flex justify-between mb-1.5 items-center">
                  <span className="text-md font-medium text-slate-200 flex items-center">
                    <Database className={`mr-2 h-5 w-5 ${supabaseStatus.connected ? 'text-green-400' : 'text-red-400'}`} />
                    Supabase
                  </span>
                  <span className={`text-md font-medium ${supabaseStatus.connected ? 'text-green-400' : 'text-red-400'}`}>
                    {supabaseStatus.connected ? 'Connected' : 'Error'}
                  </span>
                </div>
                <Progress value={supabaseStatus.connected ? 100 : 10} className={`h-2.5 [&>div]:${supabaseStatus.connected ? 'bg-green-500' : 'bg-red-500 animate-pulse'}`} />
                 {!supabaseStatus.connected && <p className="text-xs text-red-300 mt-1.5">{supabaseStatus.message}</p>}
              </div>
               <div className="p-4 bg-slate-700/60 rounded-lg shadow">
                <h4 className="font-semibold text-slate-100 mb-1">Next Steps:</h4>
                <ul className="list-disc list-inside text-sm text-slate-300 space-y-1">
                    <li>Configure IVR prompts for automated responses.</li>
                    <li>Set up softphones for agents.</li>
                    <li>Add or import contacts.</li>
                </ul>
              </div>
            </CardContent>
          </Card>
        </motion.div>
      </div>
    </div>
  );
};

export default DashboardPage;
