
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from '@/App';
import '@/index.css';
import { supabase } from '@/lib/supabaseClient'; // Ensure this line is present

// Optional: You can perform an early Supabase check here if needed, or pass client via context
if (supabase) {
  console.log("Supabase client initialized successfully in main.jsx!");
} else {
  console.error("Supabase client failed to initialize in main.jsx.");
}

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);
