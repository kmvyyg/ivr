
import React, { useState } from 'react';
import { Link, useLocation, useNavigate } from 'react-router-dom';
import { motion, AnimatePresence } from 'framer-motion';
import { Button } from '@/components/ui/button';
import { Sheet, SheetContent, SheetTrigger } from '@/components/ui/sheet';
import { Menu, X, Home, Settings, FileText, Users, Briefcase, PhoneCall, Users2, PhoneOutgoing, Contact, LogOut, ShieldCheck, Router as RouterIcon, PhoneForwarded, ListTree } from 'lucide-react';
import { supabase } from '@/lib/supabaseClient';
import { toast } from '@/components/ui/use-toast';
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";


const Layout = ({ children, user }) => {
  const [isSidebarOpen, setIsSidebarOpen] = useState(false);
  const location = useLocation();
  const navigate = useNavigate();

  const handleLogout = async () => {
    const { error } = await supabase.auth.signOut();
    if (error) {
      toast({ title: "Logout Failed", description: error.message, variant: "destructive"});
    } else {
      toast({ title: "Logged Out", description: "You have been successfully logged out."});
      navigate('/login');
    }
  };

  const commonNavItems = [
    { path: '/', label: 'Dashboard', icon: Home },
    { path: '/dialpad', label: 'Dialpad', icon: PhoneOutgoing },
    { path: '/contacts', label: 'Contacts', icon: Contact },
    { path: '/ivr', label: 'General IVR', icon: ListTree },
    { path: '/config', label: 'Call Config', icon: Briefcase },
    { path: '/reports', label: 'Call Logs', icon: FileText },
  ];

  const adminNavItems = [
    { path: '/users', label: 'User Management', icon: Users2 },
    { path: '/softphones', label: 'Softphones', icon: PhoneCall },
    { path: '/phone-numbers', label: 'Phone Numbers', icon: RouterIcon },
  ];
  
  const userInitial = user?.full_name ? user.full_name.split(' ').map(n => n[0]).join('').substring(0,2).toUpperCase() : (user?.email ? user.email.charAt(0).toUpperCase() : "?");


  const navItems = user?.role === 'admin' ? [...commonNavItems, ...adminNavItems] : commonNavItems;
  navItems.push({ path: '/settings', label: 'My Settings', icon: Settings });


  const SidebarContent = () => (
    <div className="flex flex-col h-full">
      <nav className="flex-grow flex flex-col space-y-1.5 p-3">
        {navItems.map((item) => (
          <Button
            key={item.path}
            variant={location.pathname === item.path ? 'secondary' : 'ghost'}
            className={`w-full justify-start text-base py-3 h-auto ${location.pathname === item.path ? 'bg-gradient-to-r from-green-500 to-blue-600 hover:from-green-600 hover:to-blue-700 text-white shadow-lg' : 'text-slate-300 hover:text-white hover:bg-slate-700/70'}`}
            asChild
          >
            <Link to={item.path} onClick={() => setIsSidebarOpen(false)}>
              <item.icon className="mr-3 h-5 w-5" />
              {item.label}
            </Link>
          </Button>
        ))}
      </nav>
      <div className="p-4 border-t border-slate-700">
         <div className="flex items-center space-x-3 mb-4">
            <Avatar className="h-12 w-12 border-2 border-green-500">
              <AvatarImage src={user?.user_metadata?.avatar_url || `https://ui-avatars.com/api/?name=${user?.full_name || user?.email}&background=random&color=fff`} alt={user?.full_name || user?.email} />
              <AvatarFallback className="bg-slate-600 text-white text-lg">{userInitial}</AvatarFallback>
            </Avatar>
            <div>
              <p className="text-md font-semibold text-white truncate max-w-[150px]">{user?.full_name || user?.email}</p>
              <p className="text-xs text-green-400 flex items-center">
                <ShieldCheck className="w-3.5 h-3.5 mr-1"/> {user?.role?.toUpperCase()}
              </p>
            </div>
          </div>
        <Button
          variant="outline"
          className="w-full justify-center py-3 h-auto text-red-400 border-red-500/50 hover:bg-red-500/20 hover:text-red-300 hover:border-red-400 text-base"
          onClick={handleLogout}
        >
          <LogOut className="mr-2 h-5 w-5" />
          Logout
        </Button>
      </div>
    </div>
  );

  return (
    <div className="flex h-screen overflow-hidden bg-slate-900">
      <aside className="hidden md:flex md:flex-col w-72 bg-slate-800/90 backdrop-blur-lg border-r border-slate-700/50 shadow-2xl">
        <div className="flex items-center space-x-3 px-6 py-5 border-b border-slate-700/50">
          <div className="w-12 h-12 bg-gradient-to-tr from-green-500 via-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
            <Briefcase className="w-7 h-7 text-white" />
          </div>
          <div>
            <h1 className="text-2xl font-bold text-white tracking-tight">PhoneSystem</h1>
            <p className="text-xs text-slate-400">Pro Call Center Suite</p>
          </div>
        </div>
        <SidebarContent />
      </aside>

      <Sheet open={isSidebarOpen} onOpenChange={setIsSidebarOpen}>
        <SheetTrigger asChild>
          <Button variant="ghost" size="icon" className="md:hidden fixed top-4 left-4 z-50 bg-slate-800/80 backdrop-blur-sm hover:bg-slate-700/90 text-white">
            <Menu className="h-7 w-7" />
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="w-72 bg-slate-800/95 backdrop-blur-lg p-0 border-r-0 border-slate-700/50 flex flex-col shadow-2xl">
           <div className="flex items-center space-x-3 px-6 py-5 border-b border-slate-700/50">
             <div className="w-12 h-12 bg-gradient-to-tr from-green-500 via-blue-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
               <Briefcase className="w-7 h-7 text-white" />
             </div>
             <div>
              <h1 className="text-2xl font-bold text-white tracking-tight">PhoneSystem</h1>
             </div>
           </div>
          <SidebarContent />
        </SheetContent>
      </Sheet>
      
      <div className="flex-1 flex flex-col overflow-y-auto">
        <header className="sticky top-0 md:hidden h-20 bg-slate-800/80 backdrop-blur-md border-b border-slate-700/50 flex items-center justify-center z-40 shadow-md">
          <h2 className="text-xl font-semibold text-white tracking-wide">
            {navItems.find(item => item.path === location.pathname)?.label || 'PhoneSystem Pro'}
          </h2>
        </header>
        <main className="flex-1 p-6 md:p-10 lg:p-12 bg-slate-900">
          <AnimatePresence mode="wait">
            <motion.div
              key={location.pathname}
              initial={{ opacity: 0, y: 25 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -25 }}
              transition={{ duration: 0.35, type: "spring", stiffness: 120, damping: 20 }}
            >
              {children}
            </motion.div>
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
};

export default Layout;
