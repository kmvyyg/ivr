import React, { useState } from 'react';
import { Upload, PlayCircle, Trash2, Settings as SettingsIcon, FileAudio, UploadCloud as CloudUpload, Edit3 } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { toast } from '@/components/ui/use-toast';
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";
import { supabase } from '@/lib/supabaseClient';

const IvrPromptsManager = ({ prompts, fetchIvrPrompts, loading }) => {
  const [showPromptDialog, setShowPromptDialog] = useState(false);
  const [isEditingPrompt, setIsEditingPrompt] = useState(false);
  const [currentPromptData, setCurrentPromptData] = useState({ id: null, name: '', description: '', supabase_storage_path: '', audio_url: '' });
  const [selectedAudioFile, setSelectedAudioFile] = useState(null);
  const [uploading, setUploading] = useState(false);

  const handleAudioFileChange = (event) => {
    if (event.target.files && event.target.files[0]) {
      const file = event.target.files[0];
      if (file.type === "audio/mpeg" || file.type === "audio/mp3") {
        setSelectedAudioFile(file);
        const filePath = `public_prompts/${Date.now()}_${file.name.replace(/\s+/g, '_')}`;
        setCurrentPromptData(prev => ({ ...prev, supabase_storage_path: filePath }));
      } else {
        toast({
          title: "Invalid File Type",
          description: "Please upload MP3 audio files only.",
          variant: "destructive",
        });
        setSelectedAudioFile(null);
        event.target.value = null; 
      }
    }
  };

  const resetPromptDialog = () => {
    setIsEditingPrompt(false);
    setCurrentPromptData({ id: null, name: '', description: '', supabase_storage_path: '', audio_url: '' });
    setSelectedAudioFile(null);
    setShowPromptDialog(false);
    setUploading(false);
  };

  const handleAddNewPrompt = () => {
    resetPromptDialog();
    setIsEditingPrompt(false);
    setShowPromptDialog(true);
  };
  
  const handleEditPrompt = (prompt) => {
    setIsEditingPrompt(true);
    setCurrentPromptData({
        id: prompt.id,
        name: prompt.name,
        description: prompt.description || '',
        supabase_storage_path: prompt.supabase_storage_path,
        audio_url: prompt.audio_url,
    });
    setSelectedAudioFile(null); // Don't require file re-upload for edit unless they pick one
    setShowPromptDialog(true);
  };

  const handlePromptSubmit = async () => {
    if (!currentPromptData.name.trim() || (!selectedAudioFile && !isEditingPrompt) || !currentPromptData.supabase_storage_path.trim() ) {
      toast({
        title: "Missing Information",
        description: "Prompt Name and Audio File (for new) / Storage Path are required.",
        variant: "destructive",
      });
      return;
    }

    setUploading(true);
    let audioUrl = currentPromptData.audio_url;
    let storagePath = currentPromptData.supabase_storage_path;

    if (selectedAudioFile) {
      // Upload new/replacement file
      const { data: uploadData, error: uploadError } = await supabase.storage
        .from('ivr_audio_files') // Ensure this bucket exists and is public or has correct policies
        .upload(storagePath, selectedAudioFile, {
          cacheControl: '3600',
          upsert: true, // Overwrite if path exists
        });

      if (uploadError) {
        toast({ title: "Audio Upload Failed", description: uploadError.message, variant: "destructive" });
        setUploading(false);
        return;
      }
      // Get public URL
      const { data: urlData } = supabase.storage.from('ivr_audio_files').getPublicUrl(storagePath);
      audioUrl = urlData.publicUrl;
    } else if (isEditingPrompt && !audioUrl && storagePath) {
        // If editing and no new file, but path exists, try to reconstruct URL (or re-fetch if needed)
        const { data: urlData } = supabase.storage.from('ivr_audio_files').getPublicUrl(storagePath);
        audioUrl = urlData.publicUrl;
    }


    const promptPayload = {
      name: currentPromptData.name,
      description: currentPromptData.description,
      supabase_storage_path: storagePath,
      audio_url: audioUrl,
    };

    let dbResponse;
    if (isEditingPrompt) {
      dbResponse = await supabase.from('ivr_prompts').update(promptPayload).eq('id', currentPromptData.id);
    } else {
      dbResponse = await supabase.from('ivr_prompts').insert(promptPayload);
    }

    if (dbResponse.error) {
      toast({ title: `Error ${isEditingPrompt ? 'updating' : 'adding'} prompt`, description: dbResponse.error.message, variant: "destructive" });
    } else {
      toast({ title: `Prompt ${isEditingPrompt ? 'Updated' : 'Added'} Successfully` });
      fetchIvrPrompts();
      resetPromptDialog();
    }
    setUploading(false);
  };

  const handleDeletePrompt = async (promptId, storagePath) => {
    // First, attempt to delete from storage
    if (storagePath) {
      const { error: storageError } = await supabase.storage.from('ivr_audio_files').remove([storagePath]);
      if (storageError && storageError.statusCode !== '404') { // Don't fail if file not found (already deleted?)
        toast({ title: "Error deleting audio file from storage", description: storageError.message, variant: "destructive" });
        // Optionally, decide if you want to proceed with DB deletion or not
      }
    }
    // Then, delete from database
    const { error: dbError } = await supabase.from('ivr_prompts').delete().eq('id', promptId);
    if (dbError) {
      toast({ title: "Error deleting prompt from database", description: dbError.message, variant: "destructive" });
    } else {
      toast({ title: "Prompt Deleted Successfully" });
      fetchIvrPrompts();
    }
  };

  return (
    <div>
      <div className="flex justify-end mb-4">
        <Dialog open={showPromptDialog} onOpenChange={setShowPromptDialog}>
          <DialogTrigger asChild>
            <Button onClick={handleAddNewPrompt} className="bg-sky-600 hover:bg-sky-700">
              <Upload className="mr-2 h-4 w-4" /> Add IVR Prompt
            </Button>
          </DialogTrigger>
          <DialogContent className="sm:max-w-lg bg-slate-800 border-slate-700 text-white">
            <DialogHeader>
              <DialogTitle className="text-white text-2xl">{isEditingPrompt ? 'Edit IVR Audio Prompt' : 'Add New IVR Audio Prompt'}</DialogTitle>
              <DialogDescription className="text-gray-400">
                Upload an MP3. This will be stored in Supabase Storage and linked here.
              </DialogDescription>
            </DialogHeader>
            <div className="grid gap-4 py-4 max-h-[70vh] overflow-y-auto pr-2">
              <div>
                <Label htmlFor="prompt-name">Prompt Name / Description</Label>
                <Input id="prompt-name" value={currentPromptData.name} onChange={(e) => setCurrentPromptData({...currentPromptData, name: e.target.value})} className="bg-slate-700 border-slate-600 placeholder-slate-400" placeholder="e.g., Main Menu Options"/>
              </div>
              <div>
                <Label htmlFor="prompt-description">Detailed Description (Optional)</Label>
                <Textarea id="prompt-description" value={currentPromptData.description} onChange={(e) => setCurrentPromptData({...currentPromptData, description: e.target.value})} className="bg-slate-700 border-slate-600 placeholder-slate-400" placeholder="Purpose of this prompt..."/>
              </div>
              <div>
                <Label htmlFor="prompt-storage-path">Supabase Storage Path</Label>
                <Input id="prompt-storage-path" value={currentPromptData.supabase_storage_path} onChange={(e) => setCurrentPromptData({...currentPromptData, supabase_storage_path: e.target.value})} className="bg-slate-700 border-slate-600 placeholder-slate-400" placeholder="e.g., public_prompts/main_menu.mp3" disabled={selectedAudioFile !== null && !isEditingPrompt} />
                 {selectedAudioFile && <p className="text-xs text-green-400 mt-1">Path will be: {currentPromptData.supabase_storage_path}</p>}
              </div>
              <div>
                <Label htmlFor="prompt-file">MP3 File {isEditingPrompt ? '(Optional: Replace existing)' : ''}</Label>
                <Input id="prompt-file" type="file" accept=".mp3" onChange={handleAudioFileChange} className="bg-slate-700 border-slate-600 file:text-gray-300 file:bg-slate-600 file:border-slate-500 file:rounded-md file:mr-2"/>
                {selectedAudioFile && <p className="text-xs text-green-400 mt-1">Selected: {selectedAudioFile.name}</p>}
                {isEditingPrompt && currentPromptData.audio_url && !selectedAudioFile && <p className="text-xs text-sky-400 mt-1">Current audio: <a href={currentPromptData.audio_url} target="_blank" rel="noopener noreferrer" className="underline">{currentPromptData.supabase_storage_path}</a></p>}
              </div>
            </div>
            <DialogFooter>
              <Button variant="outline" onClick={resetPromptDialog} className="text-gray-300 border-slate-600 hover:bg-slate-700" disabled={uploading}>Cancel</Button>
              <Button onClick={handlePromptSubmit} className="bg-sky-600 hover:bg-sky-700" disabled={uploading}>
                {uploading ? <><CloudUpload className="mr-2 h-4 w-4 animate-pulse" /> Uploading...</> : (isEditingPrompt ? 'Save Changes' : 'Add & Upload Prompt')}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>

      {loading ? (
        <p className="text-gray-400 text-center py-4">Loading prompts...</p>
      ) : prompts.length === 0 ? (
        <p className="text-gray-400 text-center py-4">No custom prompts configured yet.</p>
      ) : (
        <ul className="space-y-3">
          {prompts.map(prompt => (
            <li key={prompt.id} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
              <div className="flex-1 min-w-0">
                <p className="font-semibold text-white truncate" title={prompt.name}>{prompt.name}</p>
                <p className="text-xs text-gray-400 truncate" title={prompt.description}>{prompt.description || 'No description'}</p>
                <p className="text-xs text-sky-400 truncate" title={prompt.supabase_storage_path}>Path: {prompt.supabase_storage_path}</p>
                {prompt.audio_url && (
                    <a href={prompt.audio_url} target="_blank" rel="noopener noreferrer" className="text-xs text-green-400 hover:underline">Listen <PlayCircle className="inline h-3 w-3"/></a>
                )}
              </div>
              <div className="space-x-1 flex-shrink-0">
                 <Button variant="ghost" size="icon" className="text-blue-400 hover:text-blue-300" onClick={() => handleEditPrompt(prompt)}>
                    <Edit3 className="h-4 w-4" />
                  </Button>
                <AlertDialog>
                  <AlertDialogTrigger asChild>
                    <Button variant="ghost" size="icon" className="text-red-400 hover:text-red-300">
                      <Trash2 className="h-4 w-4" />
                    </Button>
                  </AlertDialogTrigger>
                  <AlertDialogContent className="bg-slate-800 border-slate-700 text-white">
                    <AlertDialogHeader>
                      <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                      <AlertDialogDescription className="text-gray-400">
                        This will delete the prompt "{prompt.name}" and its associated audio file from storage. This action cannot be undone.
                      </AlertDialogDescription>
                    </AlertDialogHeader>
                    <AlertDialogFooter>
                      <AlertDialogCancel className="text-gray-300 border-slate-600 hover:bg-slate-700">Cancel</AlertDialogCancel>
                      <AlertDialogAction onClick={() => handleDeletePrompt(prompt.id, prompt.supabase_storage_path)} className="bg-red-600 hover:bg-red-700">Delete Prompt</AlertDialogAction>
                    </AlertDialogFooter>
                  </AlertDialogContent>
                </AlertDialog>
              </div>
            </li>
          ))}
        </ul>
      )}
      <div className="mt-6 p-4 bg-sky-900/70 rounded-lg">
        <p className="text-sm text-sky-300 flex items-start">
            <SettingsIcon className="inline h-5 w-5 mr-2 flex-shrink-0 mt-0.5"/> 
            <span>
            For these prompts to work with the live Twilio IVR (via Edge Function), ensure MP3 files are uploaded to a public Supabase Storage bucket (e.g., 'ivr_audio_files'). The 'ivr_prompts' table stores the `audio_url` which the Edge Function will use. The Edge Function might also use Supabase Environment Variables for critical prompts; these ENV VARS should contain the direct public URL to the audio file.
            </span>
        </p>
      </div>
    </div>
  );
};

export default IvrPromptsManager;