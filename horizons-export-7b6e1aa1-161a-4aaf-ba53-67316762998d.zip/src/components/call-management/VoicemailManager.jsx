import React from 'react';
import { PlayCircle, Trash2, UserCircle, CalendarDays, Clock } from 'lucide-react';
import { Button } from '@/components/ui/button';
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

const VoicemailManager = ({ voicemails, loading, onPlayVoicemail, onDeleteVoicemail }) => {
  if (loading) {
    return <p className="text-gray-400 text-center py-4">Loading voicemails...</p>;
  }

  if (voicemails.length === 0) {
    return <p className="text-gray-400 text-center py-4">No voicemails.</p>;
  }
  
  const formatDuration = (seconds) => {
    if (seconds === null || seconds === undefined) return 'N/A';
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m}:${s.toString().padStart(2, '0')}`;
  };

  return (
    <ul className="space-y-3">
      {voicemails.map(vm => {
        const caller = vm.call_logs?.caller_number || vm.caller_number || 'Unknown Caller';
        const assignedUser = vm.call_logs?.users?.full_name || (vm.call_logs?.user_id ? 'Assigned User' : 'System');
        const receivedDate = new Date(vm.created_at);
        
        return (
          <li key={vm.id} className={`flex flex-col sm:flex-row items-start sm:items-center justify-between p-3 rounded-lg ${!vm.is_listened ? 'bg-yellow-600/20 ring-1 ring-yellow-500' : 'bg-slate-700/50'}`}>
            <div className="flex-1 min-w-0">
              <p className={`font-semibold ${!vm.is_listened ? 'text-yellow-200' : 'text-white'} truncate`} title={caller}>
                <UserCircle className="inline h-4 w-4 mr-1"/> From: {caller}
              </p>
              <p className="text-xs text-gray-400 truncate" title={vm.mailbox}>
                Mailbox: {vm.mailbox || 'General'}
                {vm.call_logs?.user_id && ` (For: ${assignedUser})`}
              </p>
              <div className="flex flex-wrap items-center text-xs text-gray-500 mt-1">
                <span className="mr-2 flex items-center"><Clock className="inline h-3 w-3 mr-0.5"/> Duration: {formatDuration(vm.duration_seconds)}</span>
                <span className="flex items-center"><CalendarDays className="inline h-3 w-3 mr-0.5"/> Received: {receivedDate.toLocaleDateString()} {receivedDate.toLocaleTimeString()}</span>
              </div>
              {vm.transcription && <p className="text-xs text-slate-300 mt-1 italic">"{vm.transcription.substring(0,100)}{vm.transcription.length > 100 ? '...' : ''}"</p> }
            </div>
            <div className="space-x-1 mt-2 sm:mt-0 flex-shrink-0 self-end sm:self-center">
              <Button variant="ghost" size="icon" className="text-blue-400 hover:text-blue-300" onClick={() => onPlayVoicemail(vm)}>
                <PlayCircle className="h-5 w-5" />
              </Button>
              <AlertDialog>
                <AlertDialogTrigger asChild>
                  <Button variant="ghost" size="icon" className="text-red-400 hover:text-red-300">
                    <Trash2 className="h-5 w-5" />
                  </Button>
                </AlertDialogTrigger>
                <AlertDialogContent className="bg-slate-800 border-slate-700 text-white">
                  <AlertDialogHeader>
                    <AlertDialogTitle>Delete Voicemail?</AlertDialogTitle>
                    <AlertDialogDescription className="text-gray-400">
                      Are you sure you want to delete this voicemail from {caller}? This action cannot be undone.
                    </AlertDialogDescription>
                  </AlertDialogHeader>
                  <AlertDialogFooter>
                    <AlertDialogCancel className="text-gray-300 border-slate-600 hover:bg-slate-700">Cancel</AlertDialogCancel>
                    <AlertDialogAction onClick={() => onDeleteVoicemail(vm.id)} className="bg-red-600 hover:bg-red-700">Delete</AlertDialogAction>
                  </AlertDialogFooter>
                </AlertDialogContent>
              </AlertDialog>
            </div>
          </li>
        );
      })}
    </ul>
  );
};

export default VoicemailManager;